ISTRUZIONI AGGIUNTIVE (profili attivi):
