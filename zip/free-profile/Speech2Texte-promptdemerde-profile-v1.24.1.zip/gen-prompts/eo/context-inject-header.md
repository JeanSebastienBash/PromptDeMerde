SUPLEMENTAJ INSTRUKCIOJ (aktivaj profiloj):
