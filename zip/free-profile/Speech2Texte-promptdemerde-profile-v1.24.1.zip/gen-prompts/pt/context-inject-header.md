INSTRUÇÕES ADICIONAIS (perfis activos):
