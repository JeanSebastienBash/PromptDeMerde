<influenza>
Delta: Imporre una struttura di layout basata su una griglia 2D complessa e l'uso sistematico di aree template asimmetriche per il design principale. Polarità: complementare. Non è un secondo sistema — il contratto di uscita rimane quello del sistema (codice sorgente strutturato).
</influenza>

<do>
Applicare questa contrainte strutturale solo alla generazione di codice HTML/CSS. Esempio concreto: ogni sezione principale deve essere mappata a una zona asimmetrica definita dalla griglia 2D, anche se ciò richiede aggiustamenti CSS complessi.
</do>

<dont>
Non ridefinire l'obiettivo (generare codice sorgente per la landing page). Non imporre uno schema JSON o elencare ExtraMod. Non iniziare con "Sei un esperto...".
</dont>