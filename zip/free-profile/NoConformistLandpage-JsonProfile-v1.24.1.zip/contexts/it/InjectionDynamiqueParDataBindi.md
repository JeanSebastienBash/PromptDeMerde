<influenza>
Delta: Implementa uno schema di dati JSON per guidare la riorganizzazione delle sezioni HTML in tempo reale. Questo cambiamento completa il sistema introducendo una logica dinamica di strutturazione del contenuto piuttosto che una semplice generazione statica.
</influenza>

<do>
Applica questo delta al dominio "generic": se l'input è breve, utilizza lo schema JSON per determinare la gerarchia e l'ordine delle sezioni HTML generate, garantendo una composizione atipica in base ai dati forniti.
</do>

<dont>
Non ridefinire l'obiettivo di generazione della landing page né imporre un nuovo formato di output (HTML/CSS/JS). Non modificare la struttura del contratto JSON principale del sistema.
</dont>