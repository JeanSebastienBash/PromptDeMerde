#Influenza

Delta: Decomponi il comando in unità atomiche per una struttura HTML non rigida. Polarità: complementare. Non è un secondo sistema — il contratto di output rimane quello del sistema (testo chiaro; formati UI = Workspace).

Applica solo questo delta al dominio "generic". Esempio OK: stesso sfondo, superficie modificata in base alla decomposizione atomica del comando.

Non ridefinire l'obiettivo né imporre un nuovo schema JSON / output_*, né elencare ExtraMod. Non riscrivere il sistema esistente.