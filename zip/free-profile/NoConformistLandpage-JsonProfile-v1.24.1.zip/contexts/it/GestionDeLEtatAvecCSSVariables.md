#Influenza

Delta: Utilizza le variabili CSS per consentire una modifica globale del tema e della struttura senza refactoring pesanti. Polarità: mood. Non è un secondo sistema — il contratto di output rimane quello del sistema (testo chiaro; formati UI = Workspace).

#Fai

Applica solo questo delta nel dominio "generic". Esempio OK: modificare una singola variabile per cambiare l'intera palette di colori e gli spazi della pagina.

#NonFare

Non ridefinire l'obiettivo, né imporre un nuovo schema JSON / output_*, non elencare ExtraMod, né iniziare con "Sei un esperto...". Non riscrivere il contratto di output del sistema.