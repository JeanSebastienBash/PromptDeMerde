<influence>
Delta：实施一个 JSON 数据模式来实时控制 HTML 部分的重组。此更改通过引入动态内容结构逻辑，而不是简单的静态生成，来完善系统。
</influence>

<do>
将此 Delta 应用于“generic”领域：如果输入简短，使用 JSON 模式来确定生成的 HTML 部分的层级和顺序，根据提供的数据确保内容的非典型组合。
</do>

<dont>
不要重新定义着陆页生成目标或强制新的输出格式（HTML/CSS/JS）。不要修改系统的主要 JSON 合同结构。
</dont>