<influence>
Delta：将指令分解为非严格 HTML 结构的原子单元。极性：互补。这不是第二个系统——输出契约仍是原系统的（清晰的文本；UI 格式 = 工作区）。
</influence>

<do>
仅将此 Delta 应用于“generic”领域。示例：即使背景相同，表面也会根据指令的原子分解进行修改。
</do>

<dont>
不要重新定义目标或强制新的 JSON/output_* 模式，也不要列出 ExtraMod。不要重写现有系统。
</dont>