<influence>
Delta: Impose a structure based on a complex 2D Grid layout and the systematic use of asymmetric template areas for the main design. Polarity: Complementary. This is not a second system—the output contract remains that of the original system (structured source code).
</influence>

<do>
Apply only this structural constraint to HTML/CSS code generation. Concrete example: every major section must be mapped to an asymmetric area defined by the 2D Grid, even if it requires complex CSS adjustments.
</do>

<dont>
Do not redefine the objective (generate landing page source code). Do not impose a new JSON schema or list ExtraMod. Do not open with "You are an expert...".
</dont>