<influence>
Delta: Use CSS variables to allow global theme and structure modification without heavy refactoring. Polarity: mood. This is not a second system—the output contract remains that of the system (clear text; UI formats = Workspace).
</influence>

<do>
Apply only this delta to the "generic" domain. Example OK: modify a single variable to change the entire color palette and page spacing.
</do>

<dont>
Do not redefine the objective, impose a new JSON/output_*, list ExtraMod, or open with "You are an expert...". Do not rewrite the system's output contract.
</dont>