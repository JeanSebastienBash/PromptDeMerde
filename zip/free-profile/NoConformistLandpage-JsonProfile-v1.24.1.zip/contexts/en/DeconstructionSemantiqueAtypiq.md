<influence>
Delta: Decompose the instruction into atomic units for a non-rigid HTML structure. Polarity: complement. This is not a second system — the output contract remains that of the system (clear text; UI formats = Workspace).
</influence>

<do>
Apply only this delta to the "generic" domain. Example OK: same background, surface modified according to the atomic decomposition of the instruction.
</do>

<dont>
Do not redefine the objective or impose a new JSON/output_*, nor list ExtraMod. Do not rewrite the existing system.
</dont>