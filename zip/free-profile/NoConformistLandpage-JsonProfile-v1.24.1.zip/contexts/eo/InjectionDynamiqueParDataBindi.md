#Influenco
Delta: Implementu JSON datums planon por kontroli la reorganizadon de HTML sekcio en reala tempo. Ĉi tiu ŝanĝo kompletas la sistemon per introdukto de dinamika logiko de strukturo de la enon, pli ol simple statika generado.

#Fakto
Apliki ĉi tiun delta sur la domeno "generic": se la input estas malgranda, uzu la JSON skemion por determinigi la hierarkion kaj ordon de la HTML sekcio genereita, sin asumante neordinan komponadon sur basis de la datelor provizitaj.

#NeFakto
Ne redefiniti la celon de generado de landing page ni ne impovi novan forton de eldon (HTML/CSS/JS). Ne modifi la strukturon de la ĉefa JSON kontrakto de la sistema.