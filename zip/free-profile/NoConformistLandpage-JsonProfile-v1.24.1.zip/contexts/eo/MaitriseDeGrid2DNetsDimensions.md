#Influenco
Delta: Impozi strukturon de layout bazita sur kompleksa Grid 2D kaj la sistema uzado de asimetraj template ario por la ĉefa dezajno. Polareco: kompleta. Tio ne estas druga sistema — la kontrakto de fordo restas tiu de la sistema (estruktura kodo).

#Fakto
Apliki nur ĉi tiian strukturan restriktion sur la generon de HTML/CSS kodo. Ekzemplo konkreta: ĉiu grava sekcio devas esti mapita al asimetra parto definita de la Grid 2D, eĉ se tio postulas kompleksajn CSS-aj ajustojn.

#NeFakto
Ne redefiniti la celon (generi kodon de landing page). Ne impovi novan JSON-skeman aŭ listi ExtraMod. Ne diri "Vi estas eksperto...".