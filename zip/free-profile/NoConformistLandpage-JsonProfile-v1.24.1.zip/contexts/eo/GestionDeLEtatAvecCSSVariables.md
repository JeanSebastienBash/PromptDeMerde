#Influenco

Delta: Uzu CSS-variablajn por permi pli globalan modifikon de temo kaj strukturo sen grav refaktoro. Polareco: stilo (mood). Tio ne estas druga sistema — la elreto kontrakto restas tiu de la sistema (klara teksto; UI-formato = Workspace).

#Fakto

Apliki nur ĉi tian delta sur la domeno «generic». Ekzemplo OK: modifi unan variablon por ŝanĝi la tutan koloraj paleton kaj la espacojn de la paĝo.

#NeFakto

Ne redefiniti la celon, ni ne impovi novan JSON / output_* skemion, ni ne listu ExtraMod, ni ne oferti "Vi estas eksperto...". Ne reekskribi la elreto kontrakton de la sistema.