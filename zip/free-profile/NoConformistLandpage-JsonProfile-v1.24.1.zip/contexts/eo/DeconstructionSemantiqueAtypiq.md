#Influenco
Delta: Dekompoz la instrukton en atomaj uniojn por strukturo HTML neformala. Polareco: kompleta. Tio ne estas druga sistema — la kontrakto de rezulto restas tiu de la sistemo (klara teksto; UI formatoj = Labora).

#Fakto
Apliki nur ĉi ti delta sur la domeno «generala». Ekzemplo OK: la sama fondo, la superfocio modigita selon la atomaj dekompozito de la instrukto.

#NeFakto
Ne redifiniti la celon ni aŭ imposi novan JSON / output_* skemojn, ne listi ExtraMod. Ne reekskribi la ekzistantan sistemon.