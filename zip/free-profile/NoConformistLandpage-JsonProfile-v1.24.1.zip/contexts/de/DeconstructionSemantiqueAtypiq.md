# Einfluss
Delta: Zerlege die Anweisung in atomare Einheiten für eine nicht-rigide HTML-Struktur. Polarität: Komplementär. Dies ist kein zweites System – der Ausgabekontrakt bleibt der des Systems (klarer Text; UI-Formate = Workspace).

<do>
Wende dieses Delta nur auf den Bereich „generic“ an. Beispiel OK: gleiche Hintergrundfarbe, Oberfläche modifiziert gemäß der atomaren Zerlegung der Anweisung.
</do>

<dont>
Definiere das Ziel nicht neu oder erzwinge ein neues JSON-/Output-Schema oder liste ExtraMod auf. Schreibe das bestehende System nicht um.