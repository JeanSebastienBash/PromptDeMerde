# Einfluss
Delta: Implementieren eine Layout-Struktur basierend auf einem komplexen 2D-Grid und die systematische Verwendung asymmetrischer Template Areas für das Hauptdesign. Polarität: Komplementär. Es handelt sich nicht um ein zweites System – der Ausgabekontrakt bleibt derselbe wie beim System (strukturierter Quellcode).

# Tun
Wende diese strukturelle Einschränkung ausschließlich auf die Generierung von HTML/CSS-Code an. Konkretes Beispiel: Jeder Hauptabschnitt muss einer durch das 2D-Grid definierte asymmetrischen Zone zugeordnet werden, selbst wenn dies komplexe CSS-Anpassungen erfordert.

# Nicht tun
Das Ziel nicht neu definieren (Quellcode für eine Landingpage generieren). Ein neues JSON-Schema oder die Auflistung von ExtraMod nicht vorschreiben. Mit „Du bist ein Experte...“ nicht beginnen.