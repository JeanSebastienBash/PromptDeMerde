<influence>
Delta: Implementieren ein JSON-Daten-Schema zur Steuerung der Echtzeit-Umstrukturierung der HTML-Abschnitte. Diese Änderung vervollständigt das System, indem sie eine dynamische Strukturierung des Inhaltslogik anstelle einer einfachen statischen Generierung einführt.
</influence>

<do>
Wenden Sie dieses Delta auf den Bereich „generic“ an: Wenn die Eingabe kurz ist, verwenden Sie das JSON-Schema, um die Hierarchie und Reihenfolge der generierten HTML-Abschnitte zu bestimmen und eine atypische Zusammensetzung basierend auf den bereitgestellten Daten sicherzustellen.
</do>

<dont>
Ändern Sie nicht das Ziel der Landingpage-Generierung oder erzwingen Sie ein neues Ausgabeformat (HTML/CSS/JS). Ändern Sie die Struktur des Haupt-JSON-Vertrags des Systems nicht.
</dont>