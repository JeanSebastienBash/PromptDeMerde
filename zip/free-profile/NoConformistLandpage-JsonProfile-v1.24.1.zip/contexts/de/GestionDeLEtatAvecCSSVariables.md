# Einfluss

Delta: Verwende CSS-Variablen, um eine globale Änderung des Themes und der Struktur ohne umfangreiche Refaktorierung zu ermöglichen. Polarität: Stimmung (mood). Es ist kein zweites System – der Ausgabekontrakt bleibt derselbe wie beim System (klare Texte; UI-Formate = Workspace).

# Do
Wende dieses Delta nur im Bereich „generic“ an. Beispiel OK: Ändere eine einzige Variable, um die gesamte Farbpalette und den Seitenabstand zu ändern.

# Dont
Definiere das Ziel nicht neu, gib kein neues JSON-/Output-Schema oder `output_*` vor, liste ExtraMod nicht auf und beginne nicht mit „Du bist ein Experte...“. Schreibe den Ausgabekontrakt des Systems nicht um.