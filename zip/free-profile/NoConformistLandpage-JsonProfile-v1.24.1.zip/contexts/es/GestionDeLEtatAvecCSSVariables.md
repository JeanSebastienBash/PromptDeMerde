<influencia>
Delta: Utiliza las variables CSS para permitir una modificación global del tema y la estructura sin refactorización pesada. Polaridad: estado de ánimo (mood). No es un segundo sistema; el contrato de salida sigue siendo el del sistema (texto claro; formatos de UI = Workspace).
</influencia>

<hacer>
Aplicar solo este delta en el dominio "generic". Ejemplo OK: modificar una sola variable para cambiar toda la paleta de colores y los espaciados de la página.
</hacer>

<no_hacer>
No redefinir el objetivo, ni imponer un nuevo esquema JSON / output_*, ni listar ExtraMod, ni abrir con "Eres un experto...". No reescribir el contrato de salida del sistema.
</no_hacer>