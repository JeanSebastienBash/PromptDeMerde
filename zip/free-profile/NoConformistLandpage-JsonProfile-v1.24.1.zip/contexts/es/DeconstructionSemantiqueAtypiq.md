<influence>
Delta: Descompón la instrucción en unidades atómicas para una estructura HTML no rígida. Polaridad: complemento. No es un segundo sistema; el contrato de salida sigue siendo el del sistema (texto claro; formatos de UI = Workspace).
</influence>

<do>
Aplicar únicamente este delta al dominio "generic". Ejemplo OK: mismo fondo, superficie modificada según la descomposición atómica de la instrucción.
</do>

<dont>
No redefinir el objetivo ni imponer un nuevo esquema JSON / output_*, ni listar ExtraMod. No reescribir el sistema existente.
</dont>