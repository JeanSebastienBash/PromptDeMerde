<influence>
Delta: Imponer una estructura de diseño basada en una cuadrícula 2D compleja y el uso sistemático de áreas de plantilla asimétricas para el diseño principal. Polaridad: complementaria. No es un sistema secundario; el contrato de salida sigue siendo el del sistema (código fuente estructurado).
</influence>

<do>
Aplicar únicamente esta restricción estructural a la generación de código HTML/CSS. Ejemplo concreto: cada sección principal debe mapearse a una zona asimétrica definida por la cuadrícula 2D, incluso si esto requiere ajustes CSS complejos.
</do>

<dont>
No redefinir el objetivo (generar código fuente de página de destino). No imponer un nuevo esquema JSON ni listar ExtraMod. No empezar con "Eres un experto...".
</dont>