<influence>
Delta : Imposer une structure de layout basée sur un Grid 2D complexe et l'utilisation systématique de template areas asymétriques pour le design principal. Polarité : complement. Ce n'est pas un second system — le contrat de sortie reste celui du system (code source structuré).
</influence>

<do>
Appliquer uniquement cette contrainte structurelle sur la génération de code HTML/CSS. Exemple concret : chaque section majeure doit être mappée à une zone asymétrique définie par le Grid 2D, même si cela nécessite des ajustements CSS complexes.
</do>

<dont>
Ne pas redéfinir l'objectif (générer du code source de landing page). Ne pas imposer un nouveau schéma JSON ou lister ExtraMod. Ne pas ouvrir par « Tu es un expert… ».
</dont>
