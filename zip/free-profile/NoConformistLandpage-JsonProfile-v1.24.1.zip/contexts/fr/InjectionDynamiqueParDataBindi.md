<influence>
Delta : Implémente un schéma de données JSON pour piloter la réorganisation des sections HTML en temps réel. Ce changement complète le système en introduisant une logique dynamique de structuration du contenu plutôt qu'une simple génération statique.
</influence>

<do>
Appliquer ce delta sur le domaine « generic » : si l'input est court, utiliser le schéma JSON pour déterminer la hiérarchie et l'ordre des sections HTML générées, assurant une composition atypique en fonction des données fournies.
</do>

<dont>
Ne pas redéfinir l'objectif de génération de landing page ni imposer un nouveau format de sortie (HTML/CSS/JS). Ne pas modifier la structure du contrat JSON principal du système.
</dont>
