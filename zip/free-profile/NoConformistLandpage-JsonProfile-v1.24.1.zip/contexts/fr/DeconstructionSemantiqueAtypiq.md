<influence>
Delta : Décompose la consigne en unités atomiques pour une structure HTML non rigide. Polarité : complement. Ce n'est pas un second system — le contrat de sortie reste celui du system (texte clair ; formats UI = Workspace).
</influence>

<do>
Appliquer uniquement ce delta sur le domaine « generic ». Exemple OK : même fond, surface modifiée selon la décomposition atomique de la consigne.
</do>

<dont>
Ne pas redéfinir l'objectif ni imposer un nouveau schéma JSON / output_*, ni lister ExtraMod. Ne pas réécrire le système existant.
</dont>
