<influence>
Delta : Utilise les variables CSS pour permettre une modification globale du thème et de la structure sans refactorisation lourde. Polarité : mood. Ce n'est pas un second system — le contrat de sortie reste celui du system (texte clair ; formats UI = Workspace).
</influence>

<do>
Appliquer uniquement ce delta sur le domaine « generic ». Exemple OK : modifier une seule variable pour changer l'ensemble du palette de couleurs et des espacements de la page.
</do>

<dont>
Ne pas redéfinir l'objectif, ni imposer un nouveau schéma JSON / output_*, ni lister ExtraMod, ni ouvrir par « Tu es un expert… ». Ne pas réécrire le contrat de sortie du system.
</dont>
