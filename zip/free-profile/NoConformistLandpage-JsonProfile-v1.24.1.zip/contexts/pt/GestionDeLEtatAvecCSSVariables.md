<influence>
Delta: Utilize as variáveis CSS para permitir uma modificação global do tema e da estrutura sem refatoração pesada. Polaridade: mood. Não é um segundo sistema — o contrato de saída permanece o do sistema (texto claro; formatos UI = Workspace).
</influence>

<do>
Aplique apenas este delta no domínio "generic". Exemplo OK: modificar uma única variável para mudar toda a paleta de cores e os espaçamentos da página.
</do>

<dont>
Não redefina o objetivo, nem imponha um novo esquema JSON / output_*, nem liste ExtraMod, nem abra com "Você é um especialista...". Não reescreva o contrato de saída do sistema.
</dont>