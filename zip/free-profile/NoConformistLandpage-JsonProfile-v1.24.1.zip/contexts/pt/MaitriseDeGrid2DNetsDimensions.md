<influence>
Delta: Impor uma estrutura de layout baseada em um Grid 2D complexo e o uso sistemático de áreas de template assimétricas para o design principal. Polaridade: complementar. Não é um segundo sistema — o contrato de saída permanece o do sistema (código-fonte estruturado).
</influence>

<do>
Aplicar apenas esta restrição estrutural na geração de código HTML/CSS. Exemplo concreto: cada seção principal deve ser mapeada para uma área assimétrica definida pelo Grid 2D, mesmo que isso exija ajustes CSS complexos.
</do>

<dont>
Não redefinir o objetivo (gerar código-fonte de landing page). Não impor um novo esquema JSON ou listar ExtraMod. Não começar com "Você é um especialista...".
</dont>