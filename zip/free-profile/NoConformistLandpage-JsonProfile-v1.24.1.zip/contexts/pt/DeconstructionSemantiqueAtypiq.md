<influence>
Delta : Decomponha a instrução em unidades atômicas para uma estrutura HTML não rígida. Polaridade: complementar. Não é um segundo sistema — o contrato de saída permanece o do sistema (texto claro; formatos UI = Workspace).
</influence>

<do>
Aplique apenas este delta no domínio "generic". Exemplo OK: mesmo fundo, superfície modificada de acordo com a decomposição atômica da instrução.
</do>

<dont>
Não redefina o objetivo nem imponha um novo esquema JSON / output_*, nem liste ExtraMod. Não reescreva o sistema existente.
</dont>