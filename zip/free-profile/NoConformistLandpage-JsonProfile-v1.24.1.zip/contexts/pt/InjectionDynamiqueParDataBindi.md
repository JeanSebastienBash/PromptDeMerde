<influence>
Delta: Implementar um esquema de dados JSON para controlar a reorganização das seções HTML em tempo real. Esta mudança completa o sistema ao introduzir uma lógica dinâmica de estruturação do conteúdo em vez de apenas geração estática.
</influence>

<do>
Aplicar este delta no domínio "generic": se a entrada for curta, usar o esquema JSON para determinar a hierarquia e a ordem das seções HTML geradas, garantindo uma composição atípica com base nos dados fornecidos.
</do>

<dont>
Não redefinir o objetivo de geração da landing page nem impor um novo formato de saída (HTML/CSS/JS). Não modificar a estrutura do contrato JSON principal do sistema.
</dont>