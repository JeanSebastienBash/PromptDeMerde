INSTRUCCIONES ADICIONALES (#Etiquetas activas) — solo cambios de influencia;
NO reemplazan el contrato JSON del sistema. Fusionar sin un segundo esquema.
<do>Aplicar polaridad.</do>
<dont>Duplicar output_contract.</dont>