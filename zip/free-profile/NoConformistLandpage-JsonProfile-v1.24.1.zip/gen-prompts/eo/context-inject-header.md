# INSTRUKCIJ ADDICIONALES (#Tag aktiva) — delta de influo solo;
ne subministas NE la kontrak JSON de sistema. Fuzas sen dovita skema.
<do>Apliki polaritaton.</do>
<DONT>Duplika output_kontrak.</DONT>