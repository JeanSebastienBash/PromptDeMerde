# Intenco de la uzanto por krei #Etiketo (domajno ĝenera).
<rangado>Demandigi la delta de influo je vizita — ne alia sistema sekundaro.</rangado>
<kontrakto de rezulto>Kura kruta intenco teksto aŭ JSON se demandite.</kontrakto de rezulto.
<facio>Clarigi registron / restriktion aligitaj sur: El de korta direkto, generi la shofte kodon de longa landing page (HTML/CSS/JS aŭ ekvivalent) kun volontere neklasa strukturo: komputa.</facio>
<nefacas>Akcepti ExtraMod aŭ baby « eksperto ».</nefacas.
<anti-patronoj>Ekster la domeno · junk · sekundaro sistema.</anti-patronoj.