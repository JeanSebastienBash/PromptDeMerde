재시도: 유효한 JSON {태그, 프롬프트}를 생성하세요. 구조는 영향만 포함해야 합니다.
<anti_patterns>베이비 전문가 · ExtraMod</anti_patterns>