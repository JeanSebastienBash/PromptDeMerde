Повторить: сгенерируй действительный JSON {tag,prompt}, структура только на основе влияния.
<anti_patterns>baby expert · ExtraMod</anti_patterns>