Tentar: regenere um JSON {tag, prompt} válido, estrutura influência-somente.
<anti_patterns>especialista bebê · ExtraMod</anti_patterns>