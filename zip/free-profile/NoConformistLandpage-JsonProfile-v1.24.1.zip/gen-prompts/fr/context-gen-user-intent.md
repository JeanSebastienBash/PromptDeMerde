<role>Intention utilisateur pour créer un #Tag (domaine generic).</role>
<scope>Demander le delta d'influence souhaité — pas un second system.</scope>
<output_contract>Texte court d'intention ou JSON si demandé.</output_contract>
<do>Clarifier registre / contrainte alignés sur : À partir d’une consigne courte, générer le code source d’une longue landing page (HTML/CSS/JS ou équivalent) à structure volontairement non classique : composit</do>
<dont>Accepter ExtraMod ou baby « expert ».</dont>
<anti_patterns>Hors domaine · junk · second system.</anti_patterns>
