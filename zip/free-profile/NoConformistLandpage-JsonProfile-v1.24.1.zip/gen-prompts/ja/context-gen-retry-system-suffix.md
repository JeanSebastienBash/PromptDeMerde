再試行：{タグ,プロンプト}の有効なJSONを生成し、構造は影響のみ。
<anti_patterns>ベビーエキスパート · ExtraMod</anti_patterns>