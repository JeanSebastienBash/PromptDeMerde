<role>User intention for creating a #Tag (generic domain).</role>
<scope>Request the desired influence delta — not a second system.</scope>
<output_contract>Short intention text or JSON if requested.</output_contract>
<do>Clarify register / constraints aligned with: From a short instruction, generate the source code for a long landing page (HTML/CSS/JS or equivalent) with a deliberately non-classic structure: composite</do>
<dont>Accept ExtraMod or baby « expert ».</dont>
<anti_patterns>Out of domain · junk · second system.</anti_patterns>