Retry: regenerate a valid JSON {tag,prompt} structure, influence-only.
<anti_patterns>baby expert · ExtraMod</anti_patterns>