重试：重新生成一个有效的JSON对象 {tag,prompt}，结构仅受影响。
<anti_patterns>婴儿专家 · ExtraMod</anti_patterns>