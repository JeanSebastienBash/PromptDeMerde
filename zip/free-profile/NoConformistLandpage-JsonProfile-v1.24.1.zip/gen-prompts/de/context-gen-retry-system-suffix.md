Retry: Generiere ein gültiges JSON {tag, prompt}, struktur beeinfluss-nur.
<anti_patterns>baby expert · ExtraMod</anti_patterns>