<influencia>
Delta: Redacta metadatos orientados a beneficios para maximizar la tasa de clics (CTR). Polaridad: estado de ánimo. No es un segundo sistema; el contrato de salida sigue siendo el del sistema (texto claro; formatos de UI = Workspace).
</influencia>

<hacer>
Aplicar solo este delta al dominio "seo". El título y la descripción deben destacar los beneficios directos para el usuario para incentivar el clic.
Ejemplo OK: Transformar una descripción neutral en una llamada a la acción basada en la resolución de un problema específico.
</hacer>

<no>
No redefinir el objetivo, ni imponer un nuevo esquema JSON / output_*, ni listar ExtraMod. No empezar con "Eres un experto...".
Ejemplo KO: Segundo sistema que reemplace el contrato de salida o que añada imágenes no solicitadas.
</no>