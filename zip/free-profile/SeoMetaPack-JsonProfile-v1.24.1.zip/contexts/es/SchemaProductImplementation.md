<output_contract>
<influence>
Delta: Implementación estricta de Schema.org JSON-LD para Rich Snippets SEO. Polaridad: complemento. No se trata de un segundo sistema; el contrato de salida sigue siendo el del sistema (texto claro; formatos UI = Workspace).
</influence>

<do>
Aplicar únicamente este delta al dominio "seo". Ejemplo OK: generar etiquetas title, meta description y texto schema FAQ sin incluir imágenes.
</do>

<dont>
No redefinir el objetivo ni imponer un nuevo esquema JSON / output_*, ni listar ExtraMod. No empezar con "Eres un experto...".
</dont>
</output_contract>