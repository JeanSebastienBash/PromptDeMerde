<influencia>
Delta: Dirigirse a la cola larga mediante preguntas frecuentes ultra específicas para capturar la intención precisa del usuario. Polaridad: complementaria. No se trata de un segundo sistema; el contrato de salida sigue siendo el del sistema (texto claro; formatos de UI = Workspace).
</influencia>

<hacer>
Formular pares de Pregunta/Respuesta que integren términos de búsqueda complejos y específicos del producto, evitando preguntas genéricas.
</hacer>

<no_hacer>
No redefinir el objetivo SEO ni imponer un nuevo esquema JSON / output_*, ni listar ExtraMod. No empezar con "Eres un experto...".
</no_hacer>