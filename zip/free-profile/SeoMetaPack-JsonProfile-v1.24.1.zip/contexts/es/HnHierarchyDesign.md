<influence>
Delta: Diseñar una estructura H1/H2/H3 lógica que asegure la capacidad de rastreo semántico. Polaridad: complementaria. No es un sistema secundario; el contrato de salida sigue siendo el del sistema (texto claro; formatos UI = Workspace).
</influence>

<do>
Aplicar únicamente este delta al dominio "seo". Ejemplo concreto: Estructurar las etiquetas Hn para que cada nivel refleje una intención de búsqueda específica, optimizando así la lectura por parte de los motores de búsqueda.
</do>

<dont>
No redefinir el objetivo ni imponer un nuevo esquema JSON / output_*, ni listar ExtraMod. No reescribir el contrato de salida existente.
</dont>