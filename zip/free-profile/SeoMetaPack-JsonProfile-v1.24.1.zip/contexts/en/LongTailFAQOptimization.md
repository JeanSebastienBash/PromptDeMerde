<influence>
Delta: Target the long tail via ultra-specific FAQ questions to capture precise user intent. Polarity: complementary. This is not a second system—the output contract remains that of the system (clear text; UI formats = Workspace).
</influence>

<do>
Formulate Question/Answer pairs that integrate complex and product-specific search terms, avoiding generic questions.
</do>

<dont>
Do not redefine the SEO objective or impose a new JSON schema / output_*, nor list ExtraMod. Do not open with "You are an expert...".
</dont>