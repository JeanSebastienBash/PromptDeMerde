<influence>
Delta: Write benefit-oriented metadata to maximize click-through rate (CTR). Polarity: mood. This is not a second system—the output contract remains that of the system (clear text; UI formats = Workspace).
</influence>

<do>
Apply only this delta to the "seo" domain. The title and description must highlight direct benefits for the user to encourage clicks.
Example OK: Transform a neutral description into a call-to-action based on solving a specific problem.
</do>

<dont>
Do not redefine the objective, impose a new JSON/output schema, or list ExtraMod. Do not open with "You are an expert...".
Example KO: A second system that replaces the output contract or adds unwanted images.
</dont>