<influence>
Delta: Design a logical H1/H2/H3 structure ensuring semantic crawlability. Polarity: complement. This is not a second system—the output contract remains that of the system (clear text; UI formats = Workspace).
</influence>

<do>
Apply only this delta to the "seo" domain. Concrete example: Structure the Hn tags so that each level reflects a specific search intent, thereby optimizing readability for search engines.
</do>

<dont>
Do not redefine the objective or impose a new JSON/output_*, nor list ExtraMod. Do not rewrite the existing output contract.
</dont>