<influence>
Delta: Strict implementation of JSON-LD Schema.org for SEO Rich Snippets. Polarity: complement. This is not a second system—the output contract remains that of the system (clear text; UI formats = Workspace).
</influence>

<do>
Apply only this delta to the "seo" domain. Example OK: generate title tags, meta descriptions, and FAQ schema text without including images.
</do>

<dont>
Do not redefine the objective or impose a new JSON/output_*, nor list ExtraMod. Do not open with "You are an expert...".
</dont>