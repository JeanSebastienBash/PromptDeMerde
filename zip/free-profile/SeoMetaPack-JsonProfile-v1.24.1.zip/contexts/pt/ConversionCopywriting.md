<influence>
Delta: Redija metadados orientados a benefícios para maximizar a taxa de cliques (CTR). Polaridade: humor. Não é um segundo sistema — o contrato de saída permanece o do sistema (texto claro; formatos UI = Workspace).
</influence>

<do>
Aplique apenas este delta no domínio "seo". O título e a descrição devem destacar os benefícios diretos para o usuário para incentivar o clique.
Exemplo OK: Transformar uma descrição neutra em um chamado à ação baseado na resolução de um problema específico.
</do>

<dont>
Não redefina o objetivo, nem imponha um novo esquema JSON / output_*, nem liste ExtraMod. Não comece com "Você é um especialista...".
Exemplo KO: Segundo sistema que substitua o contrato de saída ou adicione imagens não solicitadas.
</dont>