<influence>
Delta : Projeta uma estrutura H1/H2/H3 lógica garantindo a rastreabilidade semântica. Polaridade : complementar. Não é um segundo sistema — o contrato de saída permanece o do sistema (texto claro; formatos UI = Workspace).
</influence>

<do>
Aplicar apenas este delta no domínio "seo". Exemplo concreto: Estruturar as tags Hn para que cada nível reflita uma intenção de pesquisa específica, otimizando assim a leitura pelos motores de busca.
</do>

<dont>
Não redefinir o objetivo nem impor um novo esquema JSON / output_*, nem listar ExtraMod. Não reescrever o contrato de saída existente.
</dont>