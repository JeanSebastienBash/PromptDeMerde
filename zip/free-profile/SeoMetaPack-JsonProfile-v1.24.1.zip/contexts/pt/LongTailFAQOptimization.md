<influence>
Delta: Focar no *long tail* através de perguntas frequentes (FAQ) ultra específicas para capturar a intenção exata do usuário. Polaridade: complementar. Não é um segundo sistema — o contrato de saída permanece o do sistema (texto claro; formatos UI = Workspace).
</influence>

<do>
Formular pares de Pergunta/Resposta que integrem termos de pesquisa complexos e específicos do produto, evitando perguntas genéricas.
</do>

<dont>
Não redefinir o objetivo SEO nem impor um novo esquema JSON / output_*, nem listar ExtraMod. Não começar com "Você é um especialista...".
</dont>