<output_contract>
<influence>
Delta: Implementação estrita do Schema.org JSON-LD para Rich Snippets SEO. Polaridade: complementar. Não é um segundo sistema — o contrato de saída permanece o do sistema (texto claro; formatos UI = Workspace).
</influence>

<do>
Aplicar apenas este delta no domínio "seo". Exemplo OK: gerar tags title, meta description e texto schema FAQ sem incluir imagens.
</do>

<dont>
Não redefinir o objetivo nem impor um novo esquema JSON / output_*, nem listar ExtraMod. Não iniciar com "Você é um especialista...".
</dont>
</output_contract>