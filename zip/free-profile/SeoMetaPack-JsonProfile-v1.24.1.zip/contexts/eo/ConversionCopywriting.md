<influenco>
Delta: Skribi metadatumojn orientajn benefito por maksimi la klikaj raton (CTR). Polareco: stilo emocio. Tio ne estas druga sistema — la elreto de forto restas tiu de la sistema (klara teksto; UI formatoj = Workspace).
</influenco>

<facio>
Apliki nur ĉi ti delta sur la domeno „seo“. La titolo kaj la deskripcio devas emfazi direkajn benefitojn por la uzanto por stimuli klikon.
Egzemplo OK: Transformi neutralan deskripcon en aktivan uzado bazita sur la solvado de specifika problemo.
</facio>

<nefacio>
Ne redifiniĝu la celon, ni ne impovi novan JSON / output_* skemion, ni ne listu ExtraModo. Ne aliri per „Vi estas eksperto…“.
Egzemplo KO: Druga sistema kiu substitui la elreto aŭ aldon imageojn kiuj ne estis demanditaj.
</nefacio>