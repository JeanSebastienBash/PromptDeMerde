<influence>
Delta: Konceptas logan H1/H2/H3 strukturon, ki garantas semantica krawlability. Polareco: kompleta. Tio ne estas druga sistema — la kontrakto de forto restas tiu de la sistemo (klara teksto; UI formatoj = Workspace).
</influence>

<do>
Apliki nur ĉi ti delta al domeno «seo». Ekzemplo konkreta: Strukturi la Hn tagojn tiel, ke ĉiu nivel reflektas specifan serĉajn intencojn, optimante tiel la legeton de motoroj de serĉado.
</do>

<dont>
Ne redifiniti la celon aŭ imposi novan JSON / output_* skemion, ni ne listu ExtraModo. Ne reekskribi la ekzistantan kontrakton de forto.
</dont>