# Kontrakto de rezulto
<influenco>
Delta: Strikta implementado de JSON-LD Schema.org por Rich Snippets SEO. Polareco: kompleta. Tio ne estas druga sistema — la kontrakto de forto restas tiu de la sistema (klara teksto; UI formatoj = Workspace).
</influenco>

<facio>
Apliki nur ĉi ti delta sur la domeno « seo ». Ekzemplo OK: generi titolaj tagilojn, meta deskripcio kaj FAQ skema tekston sen inkluzado de imagoj.
</facio>

<ne_facio>
Ne redefiniti la celon aŭ imposi novan JSON / output_* skemion, ni ne listi ExtraMod. Ne ofri per « Vi estas eksperto… ».
</ne_facio>