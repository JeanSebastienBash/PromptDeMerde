#Influenco
Delta: Targetu la longa traŭlon per ultra-specifa FAQ por kapti la precizan intencon de la uzanto. Polareco: kompleta. Tio ne estas druga sistema — la eliri kontrakto restas tiu de la sistema (klara teksto; UI formatoj = Workspace).

#Fari
Formuli parojn de Demando/Respondo kiuj inkluzas kompleksajn kaj specifajn bezeco-termojn por la produkto, evitant ĝenerala demandojn.

#NeFari
Ne redefiniti la SEO celon aŭ imposi novan JSON / output_* ŝemion, ni ne listi ExtraMod. Ne komenci per "Vi estas eksperto...".