<influenza>
Delta: Scrivere metadati orientati ai benefici per massimizzare il tasso di clic (CTR). Polarità: umore. Non è un secondo sistema, il contratto di uscita rimane quello del sistema (testo chiaro; formati UI = Workspace).
</influenza>

<do>
Applicare solo questo delta al dominio "seo". Titolo e descrizione devono mettere in risalto i benefici diretti per l'utente per incoraggiare il clic.
Esempio OK: Trasformare una descrizione neutra in un invito all'azione basato sulla risoluzione di un problema specifico.
</do>

<dont>
Non ridefinire l'obiettivo, né imporre uno schema JSON / output_* nuovo, né elencare ExtraMod. Non iniziare con "Sei un esperto...".
Esempio KO: Secondo sistema che sostituisce il contratto di uscita o aggiunge immagini non richieste.
</dont>