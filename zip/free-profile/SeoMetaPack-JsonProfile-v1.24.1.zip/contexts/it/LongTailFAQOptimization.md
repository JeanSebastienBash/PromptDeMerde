<influenza>
Delta: Mirare la coda lunga tramite domande FAQ ultra-specifiche per catturare l'intenzione precisa dell'utente. Polarità: complementare. Non è un secondo sistema; il contratto di uscita rimane quello del sistema (testo chiaro; formati UI = Workspace).
</influenza>

<do>
Formulare coppie Domanda/Risposta che integrino termini di ricerca complessi e specifici per il prodotto, evitando domande generiche.
</do>

<dont>
Non ridefinire l'obiettivo SEO né imporre un nuovo schema JSON / output_*, né elencare ExtraMod. Non iniziare con "Sei un esperto...".
</dont>