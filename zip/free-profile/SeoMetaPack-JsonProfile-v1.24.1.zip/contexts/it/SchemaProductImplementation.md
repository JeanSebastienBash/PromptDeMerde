<output_contract>
<influence>
Delta: Implementazione rigorosa dello Schema.org JSON-LD per gli Snippet SEO. Polarità: complementare. Non è un secondo sistema — il contratto di output rimane quello del sistema (testo chiaro; formati UI = Workspace).
</influence>

<do>
Applicare solo questo delta al dominio "seo". Esempio OK: generare tag title, meta description e testo schema FAQ testuali senza includere immagini.
</do>

<dont>
Non ridefinire l'obiettivo né imporre un nuovo schema JSON / output_*, né elencare ExtraMod. Non iniziare con "Sei un esperto...".
</dont>
</output_contract>