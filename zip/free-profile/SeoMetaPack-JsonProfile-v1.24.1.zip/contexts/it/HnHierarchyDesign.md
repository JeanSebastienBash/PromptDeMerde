<influence>
Delta: Progetta una struttura H1/H2/H3 logica che assicuri la crawlability semantica. Polarità: complementare. Non è un secondo sistema — il contratto di output rimane quello del sistema (testo chiaro; formati UI = Workspace).
</influence>

<do>
Applicare solo questo delta al dominio "seo". Esempio concreto: Strutturare le tag Hn in modo che ogni livello rifletta un'intenzione di ricerca specifica, ottimizzando così la lettura da parte dei motori di ricerca.
</do>

<dont>
Non ridefinire l'obiettivo né imporre uno schema JSON / output_* nuovo, né elencare ExtraMod. Non riscrivere il contratto di output esistente.
</dont>