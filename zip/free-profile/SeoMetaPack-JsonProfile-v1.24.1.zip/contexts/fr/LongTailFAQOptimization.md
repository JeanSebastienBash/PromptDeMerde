<influence>
Delta : Cibler la longue traîne via des questions FAQ ultra-spécifiques pour capturer l'intention utilisateur précise. Polarité : complement. Ce n'est pas un second system — le contrat de sortie reste celui du system (texte clair ; formats UI = Workspace).
</influence>

<do>
Formuler des paires Question/Réponse qui intègrent des termes de recherche complexes et spécifiques au produit, en évitant les questions génériques.
</do>

<dont>
Ne pas redéfinir l'objectif SEO ni imposer un nouveau schéma JSON / output_*, ni lister ExtraMod. Ne pas ouvrir par « Tu es un expert… ».
</dont>
