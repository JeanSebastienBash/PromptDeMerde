```xml
<influence>
Delta : Conçoit une structure H1/H2/H3 logique assurant la crawlability sémantique. Polarité : complement. Ce n'est pas un second system — le contrat de sortie reste celui du system (texte clair ; formats UI = Workspace).
</influence>

<do>
Appliquer uniquement ce delta sur le domaine « seo ». Exemple concret : Structurer les balises Hn pour que chaque niveau reflète une intention de recherche spécifique, optimisant ainsi la lecture par les moteurs de recherche.
</do>

<dont>
Ne pas redéfinir l'objectif ni imposer un nouveau schéma JSON / output_*, ni lister ExtraMod. Ne pas réécrire le contrat de sortie existant.
</dont>
