<influence>
Delta : Rédige des métadonnées orientées bénéfices pour maximiser le taux de clic (CTR). Polarité : mood. Ce n'est pas un second system — le contrat de sortie reste celui du system (texte clair ; formats UI = Workspace).
</influence>

<do>
Appliquer uniquement ce delta sur le domaine « seo ». Le titre et la description doivent mettre en avant les bénéfices directs pour l'utilisateur afin d'inciter au clic.
Exemple OK : Transformer une description neutre en un appel à l'action basé sur la résolution d'un problème spécifique.
</do>

<dont>
Ne pas redéfinir l'objectif, ni imposer un nouveau schéma JSON / output_*, ni lister ExtraMod. Ne pas ouvrir par « Tu es un expert… ».
Exemple KO : Second système qui remplace le contrat de sortie ou qui ajoute des images non demandées.
</dont>
