<output_contract>
<influence>
Delta : Implémentation stricte du JSON-LD Schema.org pour les Rich Snippets SEO. Polarité : complement. Ce n'est pas un second système — le contrat de sortie reste celui du système (texte clair ; formats UI = Workspace).
</influence>

<do>
Appliquer uniquement ce delta sur le domaine « seo ». Exemple OK : générer des balises title, meta description et FAQ schema textuelle sans inclure d'images.
</do>

<dont>
Ne pas redéfinir l'objectif ni imposer un nouveau schéma JSON / output_*, ni lister ExtraMod. Ne pas ouvrir par « Tu es un expert… ».
</dont>
</output_contract>
