<influence>
Delta: Strikte Implementierung von JSON-LD Schema.org für Rich Snippets SEO. Polarität: ergänzend. Es ist kein zweites System – der Ausgabevertrag bleibt der des Systems (klarer Text; UI-Formate = Workspace).
</influence>

<do>
Wenden Sie dieses Delta nur auf den Bereich „SEO“ an. Beispiel OK: Generieren Sie Titel-Tags, Meta-Beschreibungen und FAQ Schema-Text ohne Bilder einzubeziehen.
</do>

<dont>
Das Ziel nicht neu definieren oder ein neues JSON-/Output-Schema auferlegen; ExtraMod nicht auflisten. Nicht mit „Du bist ein Experte...“ beginnen.
</dont>