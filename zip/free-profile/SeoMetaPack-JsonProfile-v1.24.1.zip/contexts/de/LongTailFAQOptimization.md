<influence>
Delta: Zielgruppen durch hochspezifische FAQ-Fragen mit langer Antwortkette ansprechen, um die genaue Nutzerabsicht zu erfassen. Polarität: Ergänzend. Dies ist kein zweites System – der Ausgabekontrakt bleibt derselbe wie beim System (klare Texte; UI-Formate = Workspace).
</influence>

<do>
Formuliere Frage/Antwort-Paare, die komplexe und produktbezogene Suchbegriffe integrieren und allgemeine Fragen vermeiden.
</do>

<dont>
Das SEO-Ziel oder ein neues JSON-/Output-Schema sowie eine Auflistung von ExtraMod neu definieren oder aufzwingen. Nicht mit „Du bist ein Experte…“ beginnen.
</dont>