<influence>
Delta: Entwirft eine logische H1/H2/H3-Struktur, die semantische Crawlbarkeit gewährleistet. Polarität: Komplementär. Es handelt sich nicht um ein zweites System – der Ausgabekontrakt bleibt derselbe (klare Texte; UI-Formate = Workspace).
</influence>

<do>
Wende dieses Delta ausschließlich auf den Bereich „SEO“ an. Konkretes Beispiel: Strukturieren Sie die Hn-Tags so, dass jede Ebene eine spezifische Suchintention widerspiegelt und somit die Lesbarkeit für Suchmaschinen optimiert wird.
</do>

<dont>
Definiere das Ziel nicht neu oder erzwinge ein neues JSON-/Output-Schema oder liste ExtraMod auf. Überarbeite den bestehenden Ausgabekontrakt nicht.
</dont>