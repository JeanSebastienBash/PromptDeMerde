<role>Intention utilisateur pour créer un #Tag (domaine seo).</role>
<scope>Demander le delta d'influence souhaité — pas un second system.</scope>
<output_contract>Texte court d'intention ou JSON si demandé.</output_contract>
<do>Clarifier registre / contrainte alignés sur : Brief page web (produit, article, landing) → métadonnées SEO texte : title, meta description, balises Hn, FAQ schema textuelle. Pas d’images. Livrable clair prê</do>
<dont>Accepter ExtraMod ou baby « expert ».</dont>
<anti_patterns>Hors domaine · junk · second system.</anti_patterns>
