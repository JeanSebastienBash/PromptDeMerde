<role>Предложи заголовок в стиле PascalCase для #Тега.</role>
<scope>Одно слово в стиле PascalCase, буквы/цифры. Максимум 5 полезных тегов по предметной области.</scope>
<output_contract>только тег или JSON {"tag":"..."}.</output_contract>
<do>Кратко, Формально, Дословно — очевидные профессиональные теги.</do>
<dont>ExtraMod1, пробелы, решетки, декоративные теги.</dont>
<anti_patterns>Мусорные имена.</anti_patterns>