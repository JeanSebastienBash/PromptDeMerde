<role>User intention for creating a #Tag (SEO domain).</role>
<scope>Request the desired influence delta — not a second system.</scope>
<output_contract>Short intent text or JSON if requested.</output_contract>
<do>Clarify register / constraints aligned with: Web page brief (product, article, landing) → SEO text metadata: title, meta description, Hn tags, FAQ schema textual. No images. Clear deliverable prep</do>
<dont>Accept ExtraMod or baby "expert".</dont>
<anti_patterns>Out of domain · junk · second system.</anti_patterns>