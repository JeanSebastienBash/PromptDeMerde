# INSTRUKCIJ ADDICIONALES (#Tag aktiva) — delta de influo solo;
ne subveni la kontrak JSON de sistema. Fuziu sen duua skema.
<do>Apliki polaritaton.</do>
<donte>Duplika output_kontrak.</donte>