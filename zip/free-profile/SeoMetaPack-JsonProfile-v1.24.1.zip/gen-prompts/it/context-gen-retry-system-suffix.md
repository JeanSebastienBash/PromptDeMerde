Riprova: rigenera un JSON {tag,prompt} valido, struttura influenza-solo.
<anti_patterns>esperto_bambini · ExtraMod</anti_patterns>