再試行：構造に影響を与えるもののみの有効なJSON {タグ,プロンプト}を再生成してください。
<anti_patterns>ベビーエキスパート · ExtraMod</anti_patterns>