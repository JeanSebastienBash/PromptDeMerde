<output_contract>
<influence>
Delta: Reformulación. El objetivo es transformar cláusulas legales crudas en lenguaje claro, conciso y directo, manteniendo estrictamente todas las restricciones duras y obligaciones iniciales. No se trata de un segundo sistema; el contrato JSON sigue siendo el del sistema (texto claro; formatos de UI = Workspace).
</influence>

<do>
Aplicar esta reformulación a una cláusula cruda: transformar la estructura compleja en frases cortas, identificando claramente la causa, la obligación y los límites sin añadir interpretación o asesoramiento legal.
Ejemplo OK: Reemplazar "En caso de incumplimiento de las obligaciones estipuladas anteriormente, el proveedor estará sujeto a sanciones proporcionales" por "Si no cumple con estas reglas, aplicaremos las penalidades previstas."
</do>

<dont>
No proporcionar asesoramiento legal, análisis o validaciones legales. No redefinir el objetivo principal (claridad del texto). No imponer un nuevo esquema JSON ni enumerar ExtraMod.
</dont>
</output_contract>