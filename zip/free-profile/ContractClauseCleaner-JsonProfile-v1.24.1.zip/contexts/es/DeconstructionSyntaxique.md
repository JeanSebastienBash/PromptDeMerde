<influencia>
Delta: Deconstrucción Sintáctica — Analiza la estructura compleja para aislar los elementos clave de la cláusula y extraer su esencia fundamental. Polaridad: complemento. No se trata de un segundo sistema; el contrato de salida sigue siendo el del sistema (texto claro, formato Workspace).
</influencia>

<hacer>
Aplicar únicamente este delta a una cláusula legal bruta para aislar la causa, la obligación y los límites en un lenguaje sencillo. Ejemplo: transformar "en virtud de las disposiciones previstas" en "porque [causa], debes [obligación] hasta [límite]".
</hacer>

<no>
No redefinir el objetivo de vulgarización ni imponer un nuevo esquema JSON / output_*. No empezar con "Eres un experto...". No es un segundo sistema.
</no>