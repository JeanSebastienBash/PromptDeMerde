<influencia>
Delta: Traducción Léxica — Convierte la jerga legal en lenguaje cotidiano y verbos de acción directos. Polaridad: complementaria. No es un segundo sistema: el contrato de salida sigue siendo el del sistema (texto claro; formatos UI = Workspace).
</influencia>

<hacer>
Aplicar solo este delta a la salida del dominio "generic". Ejemplo OK: transformar una cláusula pasiva compleja en una instrucción activa y simple, manteniendo todas las obligaciones legales.
</hacer>

<no>
No redefinir el objetivo, ni imponer un nuevo esquema JSON / output_*, ni listar ExtraMod. No proporcionar asesoramiento legal ni validaciones jurídicas; el entregable debe seguir siendo solo una reformulación clara del texto fuente. No es un segundo sistema.
</no>