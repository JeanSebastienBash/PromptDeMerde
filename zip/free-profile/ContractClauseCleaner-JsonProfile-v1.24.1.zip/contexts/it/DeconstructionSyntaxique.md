# Influenza

Delta: Decomposizione Sintattica — Analizza la struttura complessa per isolare gli elementi chiave della clausola al fine di estrarre il fondo essenziale. Polarità: complemento. Non è un secondo sistema; il contratto di output rimane quello del sistema (testo chiaro, formato Workspace).

# Azione

Applicare esclusivamente questo delta su una clausola legale grezza per isolarne la causa, l'obbligazione e i limiti in un linguaggio semplice. Esempio: trasformare "ai sensi delle disposizioni previste" in "poiché [causa], devi [obbligazione] fino a [limite]".

# Non fare

Non ridefinire l'obiettivo di divulgazione o imporre un nuovo schema JSON / output_*. Non iniziare con "Sei un esperto...". Non è un secondo sistema.