<influenco>
Delta: Leksika traduko — Konvertej la juridikan terminon al vivila lingvo kaj direktoj de akcio. Polareco: kompleta. Tio ne estas druga sistema; la elire kontrajo restas tiu de la sistema (klara teksto; UI-formato = Laboraĉo).
</influenco>

<facio>
Apliki nur ĉi tian delta al la elire domeno «generaj ». Ekzemplo OK: konverti kompleksan pasivan kluzon en aktiv kaj simplej instruojn, plene konservante la juridajn obligojn.
</facio>

<ne>
Ne redefiniti la celon, ni ne impovi novan JSON / output_* skemion, ni ne listu ExtraMod. Ne doni juridajn konsilojn aŭ validacojn; la rezulto devas resti nur klara reformulo de la vorta sintezo. Tio ne estas druga sistema.
</ne>