<output_kontrakto>
<influenco>
Delta: Reformulisto. La celo estas transformi por la juridajn kluzojn en klaran, koncizan kaj direktan lingvon, plene konservante ĉiuj rigordajn restrikovojn kaj inicialajn obloĝojn. Ĝi ne estas druga sistema — la JSON-kontrakto restas tiu de la sistema (klara teksto; UI-formato = Labora flava).
</influenco>

<facio>
Apliki ĉi ti reformulon sur bruna kluzo: transformi la kompleksan strukturon en malaj frazojn, klarigante tute kaŭzon, obloĝon kaj limojn sen aĉeti interpretadon aŭ juridikan konsilon.
Egzemplo OK: Substiuti "En caso de incumplimento das estipulitaj obloĝoj, la provizanto estos tenita al proporciaj sankcioj" per "Se vi ne respektas ĉi ti regulojn, ni aplankos la predikitan penalitojn."
</facio>

<ne_facio>
Ne doni juridajn konsilojn, analizo aŭ juridajn validacojn. Ne redefiniti la ĉefcelon (teksto klarigo). Ne imposi novan JSON-skeman aŭ listi ExtraMod.
</ne_facio>
</output_kontrakto