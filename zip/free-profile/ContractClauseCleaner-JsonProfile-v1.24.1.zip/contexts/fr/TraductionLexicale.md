<influence>
Delta : TraductionLexicale — Convertit le jargon juridique en langage courant et verbes d'action directs. Polarité : complement. Ce n'est pas un second system : le contrat de sortie reste celui du system (texte clair ; formats UI = Workspace).
</influence>

<do>
Appliquer uniquement ce delta sur la sortie domaine « generic ». Exemple OK : transformer une clause passive complexe en une instruction active et simple, tout en conservant l'intégralité des obligations légales.
</do>

<dont>
Ne pas redéfinir l'objectif, ni imposer un nouveau schéma JSON / output_*, ni lister ExtraMod. Ne pas fournir de conseils légaux ou de validations juridiques ; le livrable doit rester uniquement une reformulation claire du texte source. C'est pas un second system.
</dont>
