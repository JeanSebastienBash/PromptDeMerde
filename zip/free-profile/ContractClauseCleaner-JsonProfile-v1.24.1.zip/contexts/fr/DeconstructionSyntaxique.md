<influence>
Delta : DeconstructionSyntaxique — Analyse la structure complexe pour isoler les éléments clés de la clause afin d'en extraire le fond essentiel. Polarité : complement. Ce n'est pas un second system ; le contrat de sortie reste celui du system (texte clair, format Workspace).
</influence>

<do>
Appliquer uniquement ce delta sur une clause juridique brute pour en isoler la cause, l'obligation et les limites dans un langage simple. Exemple : transformer "en vertu des dispositions prévues" en "car [cause], vous devez [obligation] jusqu'à [limite]".
</do>

<dont>
Ne pas redéfinir l'objectif de vulgarisation ou imposer un nouveau schéma JSON / output_*. Ne pas ouvrir par « Tu es un expert… ». Ce n'est pas un second system.
</dont>
