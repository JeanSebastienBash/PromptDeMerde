```xml
<output_contract>
<influence>
Delta : Reformulation. L'objectif est de transformer des clauses juridiques brutes en langage clair, concis et direct, tout en préservant strictement toutes les contraintes dures et obligations initiales. Ce n'est pas un second système — le contrat JSON reste celui du système (texte clair ; formats UI = Workspace).
</influence>

<do>
Appliquer cette reformulation sur une clause brute : transformer la structure complexe en phrases courtes, identifiant clairement la cause, l'obligation et les limites sans ajouter d'interprétation ou de conseil légal.
Exemple OK : Remplacer "En cas de manquement aux obligations stipulées ci-dessus, le prestataire sera tenu à des sanctions proportionnelles" par "Si vous ne respectez pas ces règles, nous appliquerons les pénalités prévues."
</do>

<dont>
Ne pas fournir de conseils juridiques, d'analyses ou de validations légales. Ne pas redéfinir l'objectif principal (clarté du texte). Ne pas imposer un nouveau schéma JSON ou lister des ExtraMod.
</dont>
</output_contract>
