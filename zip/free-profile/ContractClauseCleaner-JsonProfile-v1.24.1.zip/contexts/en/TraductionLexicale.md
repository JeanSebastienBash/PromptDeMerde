<influence>
Delta: Lexical Translation — Converts legal jargon into plain language and direct action verbs. Polarity: Complementary. This is not a secondary system; the exit contract remains that of the system (clear text; UI formats = Workspace).
</influence>

<do>
Apply this delta only to the "generic" domain output. Example OK: transform a complex passive clause into an active and simple instruction, while retaining all legal obligations.
</do>

<dont>
Do not redefine the objective, impose a new JSON/output_*, or list ExtraMod. Do not provide legal advice or legal validations; the deliverable must remain only a clear reformulation of the source text. This is not a secondary system.
</dont>