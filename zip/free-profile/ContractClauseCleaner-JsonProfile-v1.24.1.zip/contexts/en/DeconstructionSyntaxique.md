# Influence

Delta: Syntactic Deconstruction — Analyze the complex structure to isolate key elements of the clause in order to extract its essential core. Polarity: Complement. This is not a secondary system; the output contract remains that of the system (clear text, Workspace format).

# Do

Apply only this delta to a raw legal clause to isolate the cause, obligation, and limits in simple language. Example: transform "en vertu des dispositions prévues" into "because [cause], you must [obligation] until [limit]".

# Don't

Do not redefine the goal of simplification or impose a new JSON/output\_* schema. Do not open with "You are an expert...". This is not a secondary system.