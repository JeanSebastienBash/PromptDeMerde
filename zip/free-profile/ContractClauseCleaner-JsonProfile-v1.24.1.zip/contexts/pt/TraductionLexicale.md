<influence>
Delta : Tradução Lexical — Converte a terminologia jurídica em linguagem comum e verbos de ação diretos. Polaridade: complementar. Não é um segundo sistema: o contrato de saída permanece o do sistema (texto claro; formatos UI = Workspace).
</influence>

<do>
Aplicar apenas este delta na saída do domínio "generic". Exemplo OK: transformar uma cláusula passiva complexa em uma instrução ativa e simples, mantendo todas as obrigações legais.
</do>

<dont>
Não redefinir o objetivo, nem impor um novo esquema JSON / output_*, nem listar ExtraMod. Não fornecer conselhos jurídicos ou validações legais; a entrega deve permanecer apenas uma reformulação clara do texto fonte. Não é um segundo sistema.
</dont>