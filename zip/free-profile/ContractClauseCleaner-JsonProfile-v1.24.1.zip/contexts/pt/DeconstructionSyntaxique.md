<influence>
Delta : Desconstrução Sintática — Analisar a estrutura complexa para isolar os elementos chave da cláusula e extrair o conteúdo essencial. Polaridade: complementar. Não é um segundo sistema; o contrato de saída permanece o do sistema (texto claro, formato Workspace).
</influence>

<do>
Aplicar apenas este delta em uma cláusula jurídica bruta para isolar a causa, a obrigação e os limites em linguagem simples. Exemplo: transformar "en vertu des dispositions prévues" em "porque [causa], você deve [obrigação] até [limite]".
</do>

<dont>
Não redefinir o objetivo de simplificação ou impor um novo esquema JSON / output_*. Não começar com "Você é um especialista...". Não é um segundo sistema.
</dont>