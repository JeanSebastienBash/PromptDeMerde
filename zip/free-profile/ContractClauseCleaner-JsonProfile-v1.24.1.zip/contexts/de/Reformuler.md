<output_contract>
<influence>
Delta: Umformulierung. Das Ziel ist es, rohe juristische Klauseln in eine klare, prägnante und direkte Sprache zu verwandeln, während alle ursprünglichen harten Einschränkungen und Verpflichtungen strikt beibehalten werden. Es handelt sich nicht um ein zweites System – das JSON-Kontrakt bleibt das des Systems (klare Texte; UI-Formate = Workspace).
</influence>

<do>
Diese Umformulierung auf eine rohe Klausel anwenden: Die komplexe Struktur in kurze Sätze umwandeln und die Ursache, die Verpflichtung und die Grenzen klar identifizieren, ohne Interpretationen oder rechtliche Ratschläge hinzuzufügen. Beispiel OK: Ersetzen Sie „Im Falle eines Verstoßes gegen die oben genannten Verpflichtungen wird der Anbieter mit proportionalen Sanktionen belegt“ durch „Wenn Sie diese Regeln nicht einhalten, werden wir die vorgesehenen Strafen anwenden.“
</do>

<dont>
Keine Rechtsberatung, Analysen oder rechtlichen Validierungen bereitstellen. Das Hauptziel (Klarheit des Textes) neu definieren. Ein neues JSON-Schema auferlegen oder ExtraMod auflisten.
</dont>
</output_contract>