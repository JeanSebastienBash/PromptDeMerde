# Einfluss
Delta: Syntaktische Dekonstruktion — Analyse der komplexen Struktur, um die Schlüsselkomponenten der Klausel zu isolieren und den wesentlichen Kern zu extrahieren. Polarität: Komplement. Dies ist kein zweites System; das Ausgabeformat des Systems bleibt gleich (klare Texte, Workspace-Format).

# Tun
Wende dieses Delta ausschließlich auf eine rohe juristische Klausel an, um die Ursache, die Verpflichtung und die Grenzen in einfacher Sprache zu isolieren. Beispiel: Wandle „infolge der vorgesehenen Bestimmungen“ in „weil [Grund], müssen Sie [Verpflichtung] bis [Grenze] tun“ um.

# Nicht tun
Definiere nicht das Ziel der Vereinfachung neu oder erzwinge ein neues JSON-/Output-Schema / output_*. Beginne nicht mit „Du bist ein Experte...“. Dies ist kein zweites System.