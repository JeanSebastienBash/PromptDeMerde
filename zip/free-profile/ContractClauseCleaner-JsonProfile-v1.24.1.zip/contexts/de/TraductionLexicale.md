<influence>
Delta: Lexikalische Übersetzung — Konvertiert juristischen Fachjargon in umgangssprachliche Sprache und direkte Aktionsverben. Polarität: Komplementär. Es ist kein zweites System; der Austrittsvertrag bleibt derselbe wie das des Systems (klare Texte; UI-Formate = Workspace).
</influence>

<do>
Wende dieses Delta ausschließlich auf die Ausgabe im Bereich „generic“ an. Beispiel OK: Wandle eine komplexe passive Klausel in eine aktive und einfache Anweisung um, während alle rechtlichen Verpflichtungen vollständig erhalten bleiben.
</do>

<dont>
Definiere das Ziel nicht neu, imponiere kein neues JSON-/Output-Schema und liste ExtraMod nicht auf. Gib keine Rechtsberatung oder juristische Validierungen; die Lieferung muss eine klare Umformulierung des Quelltextes sein. Es ist kein zweites System.
</dont>