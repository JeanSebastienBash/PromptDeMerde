Retry: Generiere ein gültiges JSON {tag, prompt}, struktur beeinflussig.
<anti_patterns>baby expert · ExtraMod</anti_patterns>