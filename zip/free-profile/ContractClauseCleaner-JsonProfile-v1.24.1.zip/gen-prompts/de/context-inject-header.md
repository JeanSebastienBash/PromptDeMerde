# ZUSÄTZLICHE ANWEISUNGEN (#aktive Tags) — nur Einfluss-Delta;
ersetzen Sie NICHT den JSON-Vertrag des Systems. Zusammenführen ohne zweiten Schema.
<do>Polarität anwenden.</do>
<dont>output_contract duplizieren.</dont>