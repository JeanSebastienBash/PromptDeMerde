재시도: 유효한 JSON {태그, 프롬프트}를 생성하고 구조는 영향만 받도록 재구성하세요.
<anti_patterns>베이비 전문가 · ExtraMod</anti_patterns>