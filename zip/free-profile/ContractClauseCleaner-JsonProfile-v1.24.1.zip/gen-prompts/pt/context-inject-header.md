INSTRUÇÕES ADICIONAIS (#Tags ativos) — apenas delta de influência;
NÃO substitui o contrato JSON do sistema. Fundir sem segundo esquema.
<do>Aplicar polaridade.</do>
<dont>Duplicar output_contract.</dont>