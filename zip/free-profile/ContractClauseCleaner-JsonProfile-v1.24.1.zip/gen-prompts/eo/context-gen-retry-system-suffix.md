Retrizo: regene validan JSON {tag,prompt}, strukturo influenco-unbe.
<anti_patterns>baba eksperto · ExtraMod</anti_patterns>