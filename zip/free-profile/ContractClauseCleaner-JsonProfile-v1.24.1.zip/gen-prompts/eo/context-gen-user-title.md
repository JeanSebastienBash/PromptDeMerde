<role>Propozi un titol PascalCase por #Etiketo.</role>
<scope>Un sola vorto PascalCase, leteroj/numeroj. Maksimum 5 utile etiketoj en la domeno.</scope>
<output_contract>etiketo sola aŭ JSON {"etiketo":"..."}.</output_contract>
<do>Konciza, Formala, Verbatim — etiketo vidaj profesioj.</do>
<dont>ExtraMod1, espaco, dijeso, dekorativ etiketoj.</dont>
<anti_patterns>Nometoj junk.</anti_patterns>