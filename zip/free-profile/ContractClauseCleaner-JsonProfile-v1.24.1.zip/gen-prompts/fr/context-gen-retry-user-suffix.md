
Réessaie : corrige tag PascalCase + prompt delta structuré.
