
<constraint>Le prompt tag doit rester un delta ≤ 90 mots avec do/dont implicites.</constraint>
