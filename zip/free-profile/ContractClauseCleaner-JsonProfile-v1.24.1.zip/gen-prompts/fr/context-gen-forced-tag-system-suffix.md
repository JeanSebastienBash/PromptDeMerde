
Force un tag utile au domaine ; refuse ExtraMod et Midjourney hors domaine.
