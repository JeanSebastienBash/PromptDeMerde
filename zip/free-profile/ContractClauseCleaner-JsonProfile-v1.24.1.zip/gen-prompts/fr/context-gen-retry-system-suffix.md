
Retry : regénère un JSON {tag,prompt} valide, structure influence-only.
<anti_patterns>baby expert · ExtraMod</anti_patterns>
