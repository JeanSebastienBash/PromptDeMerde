INSTRUCTIONS SUPPLÉMENTAIRES (#Tag actifs) — deltas d'influence uniquement ;
ne remplacent PAS le contrat JSON du system. Fusionner sans second schéma.
<do>Appliquer polarité.</do>
<dont>Dupliquer output_contract.</dont>
