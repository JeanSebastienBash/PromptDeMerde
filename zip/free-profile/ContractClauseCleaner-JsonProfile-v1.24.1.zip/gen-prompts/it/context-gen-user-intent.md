<role>Intenzione dell'utente per creare un #Tag (dominio generico).</role>
<scope>Richiedere il delta di influenza desiderato — non un secondo sistema.</scope>
<output_contract>Testo breve di intenzione o JSON se richiesto.</output_contract>
<do>Chiarire registro / vincoli allineati su: Clausola legale grezza → formulazione in linguaggio chiaro (causa, obbligo, limiti). Nessun consiglio legale né validazione giuridica — solo chiarezza del testo. L</do>
<dont>Accettare ExtraMod o "esperto bambino".</dont>
<anti_patterns>Fuori dominio · spazzatura · secondo sistema.</anti_patterns>