INSTRUZIONI AGGIUNTIVE (#Tag attivi) — delta di influenza solo;
non sostituiscono il contratto JSON del sistema. Fondire senza un secondo schema.
<do>Applicare polarità.</do>
<dont>Duplicare output_contract.</dont>