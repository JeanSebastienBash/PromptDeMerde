# ADDITIONAL INSTRUCTIONS (#ActiveTags) — influence deltas only;
DO NOT replace the system JSON contract. Merge without a second schema.
<do>Apply polarity.</do>
<dont>Duplicate output_contract.</dont>