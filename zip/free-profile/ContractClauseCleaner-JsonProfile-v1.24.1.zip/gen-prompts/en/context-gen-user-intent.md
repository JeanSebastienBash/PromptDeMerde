# User intention for creating a #Tag (generic domain).
<scope>Request the desired influence delta — not a second system.</scope>
<output_contract>Short intention text or JSON if requested.</output_contract>
<do>Clarify register / constraint aligned with: raw legal clause → clear language formulation (cause, obligation, limits). No legal advice or legal validation — only text clarity. The</do>
<dont>Accept ExtraMod or baby « expert ».</dont>
<anti_patterns>Out of domain · junk · second system.</anti_patterns>