<role>为#标签提出一个PascalCase标题。</role>
<scope>单个PascalCase单词，字母/数字。最多5个与领域相关的标签。</scope>
<output_contract>仅标签或JSON {"tag":"..."}。</output_contract>
<do>简洁、正式、逐字翻译——明显的职业标签。</do>
<dont>ExtraMod1、空格、井号、装饰性标签。</dont>
<anti-patterns>垃圾名称。</anti-patterns>