أعد المحاولة: أعد توليد JSON صالح {tag, prompt}، هيكل يؤثر فقط.
<anti_patterns>خبير طفل · ExtraMod</anti_patterns>