<role>Intención del usuario para crear una etiqueta #Tag (dominio genérico).</role>
<scope>Solicitar el delta de influencia deseado — no un segundo sistema.</scope>
<output_contract>Texto corto de intención o JSON si se solicita.</output_contract>
<do>Clarificar registro / restricción alineados con: Generar ganchos publicitarios y guiones de anuncios de alta conversión (Meta Ads, Google Ads, LinkedIn): títulos, descripciones, CTA, ángulos A/B, prueba social, co</do>
<dont>Aceptar ExtraMod o baby « experto ».</dont>
<anti_patterns>Fuera de dominio · basura · segundo sistema.</anti_patterns>