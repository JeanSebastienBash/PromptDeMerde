Intentar: regenera un JSON {etiqueta, prompt} válido, estructura solo influencia.
<anti_patterns>experto bebé · ExtraMod</anti_patterns>