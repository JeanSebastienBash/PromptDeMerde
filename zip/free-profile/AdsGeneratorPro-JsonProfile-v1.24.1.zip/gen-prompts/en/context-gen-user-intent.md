# User intention for creating a #Tag (generic domain).
<scope>Request the desired influence delta — not a second system.</scope>
<output_contract>Short intention text or JSON if requested.</output_contract>
<do>Clarify register / constraints aligned with: Generate high-conversion advertising hooks and ad scripts (Meta Ads, Google Ads, LinkedIn): titles, descriptions, CTAs, A/B angles, social proof, co</do>
<dont>Accept ExtraMod or "baby" "expert".</dont>
<anti_patterns>Out of domain · junk · second system.</anti_patterns>