# INSTRUKCIJ ADDICIONALES (#Tag aktiva) — delta de influo solo;
ne subverte la kontrak JSON de sistema. Fuzion per ne duua skema.
<do>Apliki polaritaton.</do>
<ne>Duplika output_kontrak.</ne>