# Intenco de uzanto por krei #Etiketo (domajno ĝenera).
<rangado>Demandigi la delta influo je vizite — ne alia sistema sekundaro.</rangado>
<kontrakto de rezulto>Kura kruta intenco teksto aŭ JSON se demandita.</kontrakto de rezulto.
<facio>Clarigi registron / restriktion aligitaj sur: Generi artikolo-anketa kaj skriptoj reklamaj alta konvertiĝo (Meta Ads, Google Ads, LinkedIn) : titoloj, deskriptoj, CTA, A/B anguloj, socia pruvo, ko</facio>
<nefacio>Akcepti ExtraMod aŭ baby « eksperto ».</nefacio>
<anti-patronoj>Ekster la domajno · junk · sekundaro sistema.</anti-patronoj.