#タグのPascalCaseタイトルを提案してください。

<scope>単一のPascalCaseの単語、文字/数字。分野に関連する最大5つのタグ。</scope>
<output_contract>タグのみ、またはJSON {"tag":"..."}。</output_contract>
<do>簡潔に、フォーマルに、逐語的に—明確な専門用語としてのタグ。</do>
<dont>ExtraMod1、スペース、#、装飾的なタグ。</dont>
<anti-patterns>無意味な名前。</anti-patterns