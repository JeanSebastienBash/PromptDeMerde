再試行：構造は影響のみの有効なJSON {タグ、プロンプト}を再生成してください。
<anti_patterns>ベビーエキスパート · ExtraMod</anti_patterns>