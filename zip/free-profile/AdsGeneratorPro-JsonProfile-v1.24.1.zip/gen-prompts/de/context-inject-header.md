# ZUSÄTZLICHE ANWEISUNGEN (#aktive Tags) — nur Einfluss-Delta;
ersetzen NICHT den JSON-Vertrag des Systems. Zusammenführen ohne zweiten Schema.
<do>Polarität anwenden.</do>
<dont>output_contract duplizieren.</dont>