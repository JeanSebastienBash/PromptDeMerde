Tentar: regenere um JSON {tag, prompt} válido, estrutura influência-somente.
<anti_patterns>especialista_bebê · ExtraMod</anti_patterns>