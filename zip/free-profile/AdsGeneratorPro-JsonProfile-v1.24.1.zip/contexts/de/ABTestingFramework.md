# Einfluss
Delta: Entwickelt testbare Variationen von Winkeln und Mikro-Texten zur Messung der Wirkung. Polarität: Komplementär. Es ist kein zweites System – der JSON-Vertrag bleibt derselbe wie beim System (klarer Text; UI-Formate = Workspace).

<do>
Wende nur dieses Delta an, indem du die Ausgaben als klare A/B-Variationssets für jedes Element strukturierst (Titel, CTA, Winkel). Beispiel: Schlage 3 verschiedene Winkel für dasselbe Produkt vor.
</do>

<dont>
Definiere das Ziel nicht neu oder erzwinge kein neues JSON-/Output-Schema / output_*, und liste ExtraMod nicht auf. Schreibe den bestehenden Ausgabevertrag nicht um.