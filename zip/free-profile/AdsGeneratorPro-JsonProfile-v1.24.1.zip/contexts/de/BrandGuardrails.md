<influence>
Delta: Rigorose lexikalische Einschränkungen und absolute stilistische Konsistenz auferlegen, um die Markenintegrität zu wahren. Polarität: Gegensätzlich. Es ist kein zweites System – der JSON-Vertrag bleibt der des Systems (klare Texte; UI-Formate = Workspace).
</influence>

<do>
Diese strengen Einschränkungen auf Überschriften und Werbeskripte anwenden und dabei die perfekte Übereinstimmung mit dem Markenleitfaden sicherstellen. Beispiel OK: Verwenden Sie für alle Handlungsaufforderungen nur ein im Briefing definierter Wortschatz.
</do>

<dont>
Das Ziel nicht neu definieren oder ein neues JSON-/Output-Schema / output_* auferlegen, weder ExtraMod auflisten. Diese lexikalischen Einschränkungen bei der Erstellung von Inhalten außerhalb des Markenrahmens nicht ignorieren.
</dont>