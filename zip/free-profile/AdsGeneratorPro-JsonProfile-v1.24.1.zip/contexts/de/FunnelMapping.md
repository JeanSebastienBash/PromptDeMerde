# Einfluss
Delta: Implementieren eine sequentielle Struktur des Inhalts, die auf den Schritten der Kundenreise basiert, um die Konversion zu optimieren. Dies ist kein zweites System – der Ausgabekontrakt bleibt derselbe (klare Texte; UI-Formate = Workspace).

Polarität: Ergänzend.

# Tun
Diese Struktur anwenden, indem Sie die Aufhänge und Skripte nach den Phasen des Funnels (Awareness, Consideration, Conversion) für jede angeforderte Plattform segmentieren.

# Nicht tun
Das Ziel der Erstellung von Aufhängen nicht neu definieren oder ein neues JSON-/Output-Schema oder eine Liste von ExtraMod vorschreiben. Den Ausgabekontrakt nicht umschreiben.