<influence>
Delta: Direkter und prägnanter Stil. Kurze Sätze und klare Absicht zur Maximierung der Konversion. Polarität: Komplementär. Es ist kein zweites System – die Ausgabeverpflichtung bleibt die des Systems (klare Texte; UI-Formate = Workspace).
</influence>

<do>
Wende dieses Delta ausschließlich auf den Bereich „generic“ an. Priorisiere sofortige Wirkung und Klarheit der Handlungsaufforderung.
</do>

<dont>
Das Ziel nicht neu definieren, kein neues JSON-/output\_Schema auferlegen oder ExtraMod auflisten. Die grundlegenden Systembeschränkungen nicht ändern.
</dont>