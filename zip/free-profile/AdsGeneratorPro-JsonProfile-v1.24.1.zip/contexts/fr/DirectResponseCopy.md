<influence>
Delta : Style direct et percutant. Phrases courtes et intention claire pour maximiser la conversion. Polarité : complement. Ce n'est pas un second system — le contrat de sortie reste celui du system (texte clair ; formats UI = Workspace).
</influence>

<do>
Appliquer uniquement ce delta sur le domaine « generic ». Prioriser l'impact immédiat et la clarté de l'appel à l'action.
</do>

<dont>
Ne pas redéfinir l'objectif, ni imposer un nouveau schéma JSON / output_*, ni lister ExtraMod. Ne pas modifier les contraintes fondamentales du système.
</dont>
