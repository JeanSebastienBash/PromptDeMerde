<influence>
Delta : Conçoit des variations d'angles et de micro-copies testables pour mesurer l'impact. Polarité : complement. Ce n'est pas un second system — le contrat JSON reste celui du system (texte clair ; formats UI = Workspace).
</influence>

<do>
Appliquer uniquement ce delta en structurant les outputs comme des ensembles de variations A/B clairs pour chaque élément (titre, CTA, angle). Exemple : Proposer 3 angles différents pour le même produit.
</do>

<dont>
Ne pas redéfinir l'objectif ni imposer un nouveau schéma JSON / output_*, ni lister ExtraMod. Ne pas réécrire le contrat de sortie existant.
</dont>
