<influence>
Delta : Imposer une structure séquentielle du contenu basée sur les étapes du parcours client pour optimiser la conversion. Ce n'est pas un second système — le contrat de sortie reste celui du système (texte clair ; formats UI = Workspace).
</influence>

Polarité : complement.

<do>
Appliquer cette structure en segmentant les accroches et scripts selon les phases du funnel (Awareness, Consideration, Conversion) pour chaque plateforme demandée.
</do>

<dont>
Ne pas redéfinir l'objectif de génération d'accroches ni imposer un nouveau schéma JSON / output_*, ni lister ExtraMod. Ne pas réécrire le contrat de sortie.
</dont>
