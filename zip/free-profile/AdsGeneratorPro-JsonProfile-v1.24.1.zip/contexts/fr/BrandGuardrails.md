<influence>
Delta : Imposer des contraintes lexicographiques rigoureuses et une cohérence stylistique absolue pour préserver l'intégrité de la marque. Polarité : oppose. Ce n'est pas un second system — le contrat JSON reste celui du system (texte clair ; formats UI = Workspace).
</influence>

<do>
Appliquer ces contraintes strictes sur les accroches et scripts publicitaires, en veillant à l'alignement parfait avec la charte de marque. Exemple OK : Utiliser uniquement un vocabulaire défini dans le brief pour tous les CTA.
</do>

<dont>
Ne pas redéfinir l'objectif ni imposer un nouveau schéma JSON / output_*, ni lister ExtraMod. Ne pas ignorer ces contraintes lexicographiques en produisant du contenu hors périmètre de la marque.
</dont>
