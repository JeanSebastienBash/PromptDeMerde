<influência>
Delta: Impor restrições lexicográficas rigorosas e uma coerência estilística absoluta para preservar a integridade da marca. Polaridade: opõe-se. Não é um segundo sistema — o contrato JSON permanece o do sistema (texto claro; formatos UI = Workspace).
</influência>

<fazer>
Aplicar estas restrições estritas aos *hooks* e scripts publicitários, garantindo o alinhamento perfeito com a diretriz da marca. Exemplo OK: Utilizar apenas um vocabulário definido no briefing para todos os CTAs.
</fazer>

<não_fazer>
Não redefinir o objetivo nem impor um novo esquema JSON / output_* ou listar ExtraMod. Não ignorar estas restrições lexicográficas ao produzir conteúdo fora do escopo da marca.
</não_fazer>