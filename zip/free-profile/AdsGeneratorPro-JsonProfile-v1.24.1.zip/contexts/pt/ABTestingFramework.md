<influence>
Delta : Conceber variações de ângulos e micro-copias testáveis para medir o impacto. Polaridade: complementar. Não é um segundo sistema — o contrato JSON permanece o do sistema (texto claro; formatos UI = Workspace).
</influence>

<do>
Aplicar apenas este delta estruturando as saídas como conjuntos claros de variações A/B para cada elemento (título, CTA, ângulo). Exemplo: Propor 3 ângulos diferentes para o mesmo produto.
</do>

<dont>
Não redefinir o objetivo nem impor um novo esquema JSON / output_*, nem listar ExtraMod. Não reescrever o contrato de saída existente.
</dont>