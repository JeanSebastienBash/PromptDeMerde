# Influência
Delta: Impor uma estrutura sequencial do conteúdo baseada nas etapas da jornada do cliente para otimizar a conversão. Não é um segundo sistema — o contrato de saída permanece o mesmo do sistema (texto claro; formatos UI = Workspace).

Polaridade: complementar.

<fazer>
Aplicar essa estrutura segmentando os ganchos e scripts de acordo com as fases do funil (Conscientização, Consideração, Conversão) para cada plataforma solicitada.
</fazer>

<não_fazer>
Não redefinir o objetivo de geração de ganchos nem impor um novo esquema JSON / output_* ou listar ExtraMod. Não reescrever o contrato de saída.
</não_fazer>