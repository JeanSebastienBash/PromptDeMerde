#Influenco
Delta: Impozi rigorajn leksikajn restriktionojn kaj absolutan stilajn koheron por konservi la integriton de la markoj. Polareco: kontraste. Tio ne estas druga sistema — la JSON kontrakto restas tiu de la sistemo (klara teksto; UI formatoj = Laboraĉo).

#Fari
Apliki ĉi ti strictajn restriktionojn al akcantoj kaj reklama skriptoj, zorgante pri perfecta aligado kun la markaj direktivoj. Ekzemplo OK: Utilizi nur vokabaron definitan en la brief por ĉiuj CTA-j.

#NeFari
Ne redifiniti la celon aŭ impozi novan JSON / output_* skemojn, ni ne listu ExtraMod. Ne ignoru ĉi ti leksikajn restriktionojn al produkti enskribon forta de la markoj perimetro.