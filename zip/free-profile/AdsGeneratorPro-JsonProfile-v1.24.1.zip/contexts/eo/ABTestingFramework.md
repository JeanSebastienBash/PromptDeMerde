#Influenco
Delta: Konceptas variaciojn de anguloj kaj mikro-kopojn, kiuj estas testebilaj por mezuri impacton. Polareco: kompleta. Tio ne estas druga sistema — la JSON kontrakto restas tiu de la sistemo (klara teksto; UI formatoj = Workspace).

#Fari
Apliki nur ĉi tiun delta per strukturado de output kiel klara A/B variacioj por ĉiu elemento (titolo, CTA, angulo). Ekzemplo: Propozi 3 malsamajn angulojn por la sama produkto.

#NeFari
Ne redefiniti la celon aŭ imposi novan JSON / output_* skemojn, ni ne listi ExtraMod. Ne reekskribi la ekzistantan elvenaj kontrakton.