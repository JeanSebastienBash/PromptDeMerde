#Influenco
Delta: Impozi struktur sekvencan de la encontenon bazita sur paŝoj de la viaj klient por optimi konvertancon. Ĝi ne estas druga sistema — la kontrakto elchton restas tiu de la sistema (klara teksto; UI formatoj = Workspace).
Polaritato: kompleta.

<facio>
Apliki ĉi ti strukturon segmentante la akceptoj kaj skriptojn selon la fazojn de la funelo (Konscio, Konsidero, Konvertado) por ĉiu demandita platformo.
</facio>

<nefacio>
Ne redefiniti la celon generi akceptojn ni ne imopi novan JSON / output_* skemojn, ni ne listi ExtraMod. Ne reekspi skribi la kontrakton elchton.