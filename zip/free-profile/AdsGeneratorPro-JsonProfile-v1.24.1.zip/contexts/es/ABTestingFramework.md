<influence>
Delta: Diseña variaciones de ángulos y microcopias probables para medir el impacto. Polaridad: complementaria. No es un segundo sistema; el contrato JSON sigue siendo el del sistema (texto claro; formatos UI = Workspace).
</influence>

<do>
Aplicar únicamente este delta estructurando las salidas como conjuntos claros de variaciones A/B para cada elemento (título, CTA, ángulo). Ejemplo: Proponer 3 ángulos diferentes para el mismo producto.
</do>

<dont>
No redefinir el objetivo ni imponer un nuevo esquema JSON / output_*, ni listar ExtraMod. No reescribir el contrato de salida existente.