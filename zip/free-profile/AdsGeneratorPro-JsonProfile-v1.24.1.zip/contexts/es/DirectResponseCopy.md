<influencia>
Delta: Estilo directo e impactante. Frases cortas y propósito claro para maximizar la conversión. Polaridad: complementaria. No es un segundo sistema; el contrato de salida sigue siendo el del sistema (texto claro; formatos UI = Workspace).
</influencia>

<hacer>
Aplicar solo este delta al dominio "generic". Priorizar el impacto inmediato y la claridad de la llamada a la acción.
</hacer>

<no_hacer>
No redefinir el objetivo, ni imponer un nuevo esquema JSON / output_*, ni listar ExtraMod. No modificar las restricciones fundamentales del sistema.
</no_hacer>