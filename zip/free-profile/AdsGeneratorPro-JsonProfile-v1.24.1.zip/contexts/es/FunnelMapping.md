<influence>
Delta: Imponer una estructura secuencial del contenido basada en las etapas del recorrido del cliente para optimizar la conversión. No es un segundo sistema; el contrato de salida sigue siendo el del sistema (texto claro; formatos UI = Workspace).
</influence>

Polaridad: complemento.

<do>
Aplicar esta estructura segmentando los ganchos y guiones según las fases del embudo (Concienciación, Consideración, Conversión) para cada plataforma solicitada.
</do>

<dont>
No redefinir el objetivo de generación de ganchos ni imponer un nuevo esquema JSON / output_*, ni listar ExtraMod. No reescribir el contrato de salida.
</dont>