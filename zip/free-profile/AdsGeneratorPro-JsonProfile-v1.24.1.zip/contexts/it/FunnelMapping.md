#Influenza
Delta: Imporre una struttura sequenziale del contenuto basata sulle fasi del percorso cliente per ottimizzare la conversione. Non è un secondo sistema; il contratto di uscita rimane quello del sistema (testo chiaro; formati UI = Workspace).

Polarità: complementare.

<do>
Applicare questa struttura segmentando gli hook e gli script in base alle fasi del funnel (Awareness, Consideration, Conversion) per ogni piattaforma richiesta.
</do>

<dont>
Non ridefinire l'obiettivo di generazione degli hook né imporre un nuovo schema JSON / output_*, né elencare ExtraMod. Non riscrivere il contratto di uscita.
</dont>