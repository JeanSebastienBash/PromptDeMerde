#Influenza

Delta: Progetta variazioni di angoli e micro-copie testabili per misurare l'impatto. Polarità: complementare. Non è un secondo sistema — il contratto JSON rimane quello del sistema (testo chiaro; formati UI = Workspace).

Applica esclusivamente questo delta strutturando gli output come set chiari di variazioni A/B per ogni elemento (titolo, CTA, angolo). Esempio: Proponi 3 angoli diversi per lo stesso prodotto.

Non ridefinire l'obiettivo né imporre un nuovo schema JSON / output_*, né elencare ExtraMod. Non riscrivere il contratto di output esistente.