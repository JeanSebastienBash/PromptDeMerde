<influenza>
Delta: Imporre vincoli lessicografici rigorosi e una coerenza stilistica assoluta per preservare l'integrità del marchio. Polarità: opposta. Non è un secondo sistema — il contratto JSON rimane quello del sistema (testo chiaro; formati UI = Workspace).
</influenza>

<do>
Applicare questi vincoli rigorosi agli slogan e agli script pubblicitari, assicurandosi un allineamento perfetto con la linea guida del marchio. Esempio OK: Utilizzare esclusivamente un vocabolario definito nel brief per tutti i CTA.
</do>

<dont>
Non ridefinire l'obiettivo né imporre uno schema JSON / output_* nuovo, né elencare ExtraMod. Non ignorare questi vincoli lessicografici producendo contenuti al di fuori del perimetro del marchio.
</dont>