# Influence
Delta: Impose a sequential content structure based on customer journey steps to optimize conversion. This is not a second system—the output contract remains that of the system (clear text; UI formats = Workspace).

Polarity: Complement.

<do>
Apply this structure by segmenting hooks and scripts according to funnel phases (Awareness, Consideration, Conversion) for each requested platform.
</do>

<dont>
Do not redefine the hook generation objective or impose a new JSON/output\_* schema, nor list ExtraMod. Do not rewrite the output contract.
</dont>