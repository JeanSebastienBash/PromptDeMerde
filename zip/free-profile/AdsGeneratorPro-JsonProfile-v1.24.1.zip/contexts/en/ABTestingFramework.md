<influence>
Delta: Design testable variations of angles and micro-copies to measure impact. Polarity: complementary. This is not a second system—the JSON contract remains that of the existing system (clear text; UI formats = Workspace).
</influence>

<do>
Apply only this delta by structuring outputs as clear A/B variation sets for each element (title, CTA, angle). Example: Propose 3 different angles for the same product.
</do>

<dont>
Do not redefine the objective or impose a new JSON schema / output_*, nor list ExtraMod. Do not rewrite the existing output contract.
</dont>