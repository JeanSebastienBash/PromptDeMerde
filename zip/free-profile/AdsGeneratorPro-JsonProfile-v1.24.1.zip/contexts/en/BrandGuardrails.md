<influence>
Delta: Impose rigorous lexicographical constraints and absolute stylistic consistency to preserve brand integrity. Polarity: Opposes. This is not a second system—the JSON contract remains that of the system (clear text; UI formats = Workspace).
</influence>

<do>
Apply these strict constraints to headlines and ad scripts, ensuring perfect alignment with the brand guidelines. Example OK: Use only vocabulary defined in the brief for all CTAs.
</do>

<dont>
Do not redefine the objective or impose a new JSON schema / output_*, nor list ExtraMod. Do not ignore these lexicographical constraints when producing content outside the brand's scope.
</dont>