Generiere die beste Kontext-Prompt für ein Profil namens #{{title}}.
Der Tag muss exakt "{{title}}" sein (Großbuchstabe am Anfang, ohne Leerzeichen).
Die Anweisungen müssen den erwarteten Berufsbegrenzer präzise beschreiben, in Übereinstimmung mit „Prompt-List-Structurator“ / Klarifizieren und strukturieren eines rohen Prompts in eine präzise und optimierte LLM-Anweisung.