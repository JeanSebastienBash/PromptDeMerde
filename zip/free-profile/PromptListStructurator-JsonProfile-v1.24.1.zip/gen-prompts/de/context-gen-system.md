{
  "tag": "ClarteMaximale",
  "prompt": "Klarstelle und strukturiere einen rohen Prompt in eine präzise und optimierte LLM-Anweisung."
}