{
  "tag": "ClarteMaximale",
  "prompt": "Clarifica y estructura un prompt bruto en una instrucción de LLM precisa y optimizada."
}