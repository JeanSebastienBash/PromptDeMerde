Genera el mejor prompt de contexto para un perfil llamado #{{title}}.
La etiqueta debe ser exactamente "{{title}}" (mayúscula al inicio, sin espacios).
Las instrucciones deben describir con precisión el modificador de profesión esperado, en coherencia con «Prompt-List-Structurator » / Clarifica y estructura un prompt bruto en instrucción LLM precisa y optimizada..