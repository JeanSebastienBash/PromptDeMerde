# Genere la plej bone kontekstprompt por profil nomita #{{title}}.
La tag devas esti eksaktem "{{title}}" (majuskelo al laŭ, sen espaco).
Instrukcioj devas deskribi precize la modifikanton de profesia role esperita, en kohereco kun "Prompt-List-Structurator" / Klarigu kaj strukturi brutan promptn en precizajn kaj optimitan LLM instruko..