{
  "tag": "ClareStrukturo",
  "prompt": "Clarifas kaj strukturu brutan promptn en precizajn kaj optimitan LLM instrukton."
}