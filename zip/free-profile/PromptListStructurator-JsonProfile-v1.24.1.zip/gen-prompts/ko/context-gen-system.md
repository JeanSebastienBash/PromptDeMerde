{
  "tag": "ClarteMaximale",
  "prompt": "LLM 지침을 명확하고 최적화된 명령으로 구체화하고 구조화함, 짧은 문장 사용, 엄격한 제약 조건 유지."
}