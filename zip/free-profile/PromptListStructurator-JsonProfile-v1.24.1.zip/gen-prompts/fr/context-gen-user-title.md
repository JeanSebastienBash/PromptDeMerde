Génère le meilleur prompt de contexte pour un profil nommé #{{title}}.
Le tag doit être exactement "{{title}}" (majuscule au début, sans espace).
Les instructions doivent décrire précisément le modificateur métier attendu, en cohérence avec « Prompt-List-Structurator » / Clarifie et structure un prompt brut en instruction LLM précise et optimisée..