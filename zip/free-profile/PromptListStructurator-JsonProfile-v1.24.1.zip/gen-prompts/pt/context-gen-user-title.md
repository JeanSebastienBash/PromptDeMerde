Gere o melhor prompt de contexto para um perfil chamado #{{title}}.
A tag deve ser exatamente "{{title}}" (maiúscula no início, sem espaço).
As instruções devem descrever precisamente o modificador de profissão esperado, em coerência com « Prompt-List-Structurator » / Clarifique e estruture um prompt bruto em instrução LLM precisa e otimizada.