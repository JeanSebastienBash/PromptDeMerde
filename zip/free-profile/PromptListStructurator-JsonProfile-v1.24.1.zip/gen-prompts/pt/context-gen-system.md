{
  "tag": "ClarteMaximale",
  "prompt": "Clarifica e estrutura um prompt bruto em instrução LLM precisa e otimizada."
}