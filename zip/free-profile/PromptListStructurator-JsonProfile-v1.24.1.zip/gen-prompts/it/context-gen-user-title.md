Genera il miglior prompt di contesto per un profilo chiamato #{{title}}.
Il tag deve essere esattamente "{{title}}" (maiuscolo all'inizio, senza spazi).
Le istruzioni devono descrivere con precisione il modificatore professionale atteso, in coerenza con « Prompt-List-Structurator » / Clarifica e struttura un prompt grezzo in istruzione LLM precisa e ottimizzata..