{
  "tag": "ClarteMaximale",
  "prompt": "Clarifica e struttura un prompt grezzo in istruzione LLM precisa e ottimizzata."
}