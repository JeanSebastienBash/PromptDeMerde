{
  "tag": "ClarteMaximale",
  "prompt": "指示を明確にし、短いフレーズでLLMへの正確かつ最適化された命令に構造化する。"
}