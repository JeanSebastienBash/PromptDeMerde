{
  "tag": "ClarteMaximale",
  "prompt": "Clarifie l'intention, phrases courtes, conserve les contraintes dures."
}