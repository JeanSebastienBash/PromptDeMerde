Synthétise le contenu complexe en un résumé exécutif dense et informatif.
