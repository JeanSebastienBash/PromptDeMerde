Structure la sortie finale en utilisant des listes hiérarchisées ou un résumé exécutif si demandé.
