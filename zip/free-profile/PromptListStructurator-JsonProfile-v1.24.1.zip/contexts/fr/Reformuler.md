Clarifie l'intention primaire, reformule en voix active et élimine les redondances.
