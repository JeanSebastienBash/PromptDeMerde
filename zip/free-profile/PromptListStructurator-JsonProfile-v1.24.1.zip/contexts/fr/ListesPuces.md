Convertit les idées brutes en une séquence d'étapes logiques et concises.
