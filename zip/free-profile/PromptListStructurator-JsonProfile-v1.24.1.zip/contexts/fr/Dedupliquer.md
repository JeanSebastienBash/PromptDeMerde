Identifie et supprime toutes les informations redondantes ou tautologiques dans l'entrée.
