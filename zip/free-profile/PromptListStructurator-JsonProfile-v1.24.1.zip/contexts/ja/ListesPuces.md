# 元のタグ：Convertit les idées brutes en une séquence d'étapes logiques et concises.

**翻訳:**

アイデアの断片を論理的で簡潔な一連のステップに変換してください。これにより、漠然とした概念が実行可能な計画へと明確になります。各段階は明確で順序立てられており、迷いなく進めることができるように構成する必要があります。