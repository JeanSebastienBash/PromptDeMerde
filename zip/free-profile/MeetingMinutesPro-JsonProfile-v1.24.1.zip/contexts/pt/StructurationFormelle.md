<influence>
Delta: Aplique um esquema de saída fixo e modular para garantir a coerência do relatório. Polaridade: complementar. Não é um segundo sistema — o contrato de saída permanece o do sistema (texto claro; formatos UI = Workspace).
</influence>

<do>
Estruturar sistematicamente as notas brutas em seções claras: Decisões, Ações (com responsáveis e prazos) e Síntese. Exemplo: Transformar uma lista com marcadores em uma tabela estruturada para o objetivo "relatório".
</do>

<dont>
Não redefinir o objetivo de transformação ou impor um novo esquema JSON / output_*. Não incluir conselhos de negócio fora da síntese. Não é um segundo sistema que substitui o contrato principal.
</dont>