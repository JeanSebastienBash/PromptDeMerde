# Influência
Delta: Restrição estrita do conteúdo a informações factuais e decisões explícitas; oposição total a interpretações ou conselhos de negócios não explicitamente extraídos do texto fonte.

## Ação
Aplicar esta regra para transformar as notas brutas em um relatório estruturado, mantendo apenas os elementos de decisão, ações, responsáveis e prazos listados na fonte.

## Restrição
Não modificar o objetivo final nem introduzir um novo esquema de saída. Não redefinir o sistema existente.