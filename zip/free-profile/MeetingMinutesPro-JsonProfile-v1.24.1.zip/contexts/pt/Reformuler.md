<influence>
Delta: Clarifique a intenção usando frases curtas e diretas. Priorize a conservação estrita de todas as restrições rígidas do tópico. Não é um segundo sistema — o contrato JSON permanece o do sistema (texto claro; formatos UI = Workspace).
</influence>

<do>
Aplique esta reformulação para transformar notas brutas em um relatório estruturado, garantindo a máxima concisão sem sacrificar a precisão das decisões e ações.
</do>

<dont>
Não redefina o objetivo da transformação nem imponha um novo esquema JSON / output_*, nem liste ExtraMod. Nunca forneça conselhos de negócios fora da síntese factual.
</dont>