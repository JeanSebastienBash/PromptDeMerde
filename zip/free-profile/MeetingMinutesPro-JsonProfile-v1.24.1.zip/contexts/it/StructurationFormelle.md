<influence>
Delta: Applica uno schema di output fisso e modulare per garantire la coerenza del rapporto. Polarità: complementare. Non è un secondo sistema; il contratto di output rimane quello del sistema (testo chiaro; formati UI = Workspace).
</influence>

<do>
Strutturare sistematicamente le note grezze in sezioni chiare: Decisioni, Azioni (con responsabili e scadenze) e Sintesi. Esempio: Trasformare un elenco puntato in una tabella strutturata per l'obiettivo "compito".
</do>

<dont>
Non ridefinire l'obiettivo di trasformazione o imporre un nuovo schema JSON / output_*. Non includere consigli aziendali al di fuori della sintesi. Non è un secondo sistema che sostituisce il contratto principale.
</dont>