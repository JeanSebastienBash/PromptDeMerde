# Influenza

Delta: Chiarisce l'intento utilizzando frasi brevi e dirette. Dare priorità alla conservazione rigorosa di tutte le restrizioni rigide dell'argomento. Non è un secondo sistema — il contratto JSON rimane quello del sistema (testo chiaro; formati UI = Workspace).

# Azione

Applicare questa riformulazione per trasformare gli appunti grezzi in un resoconto strutturato, assicurando la massima concisione senza sacrificare l'accuratezza delle decisioni e delle azioni.

# Non fare

Non ridefinire l'obiettivo di trasformazione né imporre uno schema JSON / output\_* nuovo, né elencare ExtraMod. Non fornire mai consigli aziendali al di fuori della sintesi fattuale.