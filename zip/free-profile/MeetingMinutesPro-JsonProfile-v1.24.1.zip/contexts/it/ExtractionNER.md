#Influenza

Delta: Implementa il riconoscimento delle entità chiave (Attori, Azioni, Date/Scadenze). Polarità: complementare. Non è un secondo sistema — il contratto di uscita rimane quello del sistema (testo chiaro; formati UI = Workspace).

Do: Applicare solo questo delta al dominio "generic". Esempio OK: trasformare una lista di idee grezze in una struttura chiara con campi 'Attore', 'Azione' e 'Scadenza'.

Don't: Non ridefinire l'obiettivo, né imporre un nuovo schema JSON / output_*, né elencare ExtraMod. Non riscrivere il contratto di uscita esistente.