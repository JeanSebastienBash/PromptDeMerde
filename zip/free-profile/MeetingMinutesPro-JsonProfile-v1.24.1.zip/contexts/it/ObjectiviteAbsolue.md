# Influenza

Delta: Restrizione rigorosa del contenuto alle informazioni fattuali e alle decisioni esplicite; opposizione totale a interpretazioni o consigli aziendali non derivati esplicitamente dal testo sorgente.

Applica questa regola per trasformare gli appunti grezzi in un resoconto strutturato, conservando solo gli elementi di decisione, azioni, responsabili e scadenze elencati nella fonte.

Non modificare l'obiettivo finale né introdurre un nuovo schema di output. Non ridefinire il sistema esistente.