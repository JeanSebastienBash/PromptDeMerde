#Influenco
Delta: Strikta restriĝo de la entronado al faktojn kaj esplicitaj decidoj; totala kontraŭo al interpretacoj aŭ profesiaj konsiloj ne esplicite eltiĝantaj el la vorto-fonteco.

#Facio
Apliki ĉi ti regulon por transformi la brulajn notojn en strukturitan raporton, konservante nur la elementojn de decido, agado, respondaĵoj kaj terminoj en la vorto-fonteco.

#NeFacio
Ne modifi la finfinalan celon ni ne introdukti novan elton de rezultoj. Ne redefiniti la ekzistantan sistemon.