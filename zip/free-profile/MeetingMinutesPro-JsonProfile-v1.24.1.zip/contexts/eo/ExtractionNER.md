#Influenco

Delta: Implementu la rekoneson de la vortoj esencaj (Aktoroj, Akcioj, Dato/Terminoj). Polareco: kompleta. Tio ne estas druga sistema — la eliri kontrakto restas tiu de la sistemo (klara teksto; UI formatoj = Workspace).

#Fakto

Apliki nur ĉi tian delta sur la domeno «generaj ». Ekzemplo OK: transformi liston de brutaj ideoj en strukturon klaran kun la kampoj 'Aktor', 'Akcio' kaj 'Termino'.

#NeFakto

Ne redifiniti la celon, ni ne impovi novan JSON / output_* skemion, ni ne listu ExtraMod. Ne reekskri la ekzistantan eliri kontrakton.