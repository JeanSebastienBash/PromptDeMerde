#Influenco

Delta: Aplikas fiksaj kaj modulajn eldonon planon por garanti la koheron de raporto. Polareco: kompleta. Tio ne estas druga sistema — la eldonon kontrakto restas tiu de la sistema (klara teksto; UI formatoj = Workspace).

#Fakto

Strukturi sisteman bonebrutajn notojn en claraj sekcioj: Decizioj, Agoj (kun respondaantoj kaj terminoj) kaj Sintezo. Ekzemple: Transformi liston de punktiloj en strukturan tablon por la celo "raportado".

#NeFakto

Ne redifinitiĝu la transformiĝcelon aŭ impovi novan JSON / output_*. Ne inkluzi conseojn de merkintaj kaj ĉirkaŭ sintezo. Tio ne estas druga sistema, kiu subventus la ĉefan kontrakton.