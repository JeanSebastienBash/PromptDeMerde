# Influencia

Delta: Implementar el reconocimiento de entidades clave (Actores, Acciones, Fechas/Plazos). Polaridad: complementaria. No es un segundo sistema; el contrato de salida sigue siendo el del sistema (texto claro; formatos de UI = Workspace).

## Hacer

Aplicar únicamente este delta al dominio "generic". Ejemplo OK: transformar una lista de ideas sueltas en una estructura clara con campos 'Actor', 'Acción' y 'Plazo'.

## No hacer

No redefinir el objetivo, ni imponer un nuevo esquema JSON / output_*, ni listar ExtraMod. No reescribir el contrato de salida existente.