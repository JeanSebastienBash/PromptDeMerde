<influence>
Delta: Aplica un esquema de salida fijo y modular para garantizar la coherencia del informe. Polaridad: complementaria. No es un segundo sistema; el contrato de salida sigue siendo el del sistema (texto claro; formatos UI = Workspace).
</influence>

<do>
Estructurar sistemáticamente las notas brutas en secciones claras: Decisiones, Acciones (con responsables y plazos) y Resumen. Ejemplo: Transformar una lista con viñetas en una tabla estructurada para el objetivo "informe".
</do>

<dont>
No redefinir el objetivo de transformación ni imponer un nuevo esquema JSON / output_*. No incluir consejos comerciales fuera del resumen. Este no es un segundo sistema que reemplace al principal.
</dont>