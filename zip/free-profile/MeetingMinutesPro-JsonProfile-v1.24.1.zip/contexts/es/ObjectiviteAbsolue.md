<influencia>
Delta: Restricción estricta del contenido a información fáctica y decisiones explícitas; oposición total a interpretaciones o consejos de negocio no extraídos explícitamente del texto fuente.
</influencia>

<hacer>
Aplicar esta regla para transformar las notas brutas en un informe estructurado, conservando solo los elementos de decisión, acciones, responsables y plazos enumerados en la fuente.
</hacer>

<no>
No modificar el objetivo final ni introducir un nuevo esquema de salida. No redefinir el sistema existente.
</no>