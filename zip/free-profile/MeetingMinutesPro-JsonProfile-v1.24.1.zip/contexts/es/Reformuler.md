<influence>
Delta: Clarifica la intención utilizando frases cortas y directas. Prioriza la conservación estricta de todas las restricciones duras del tema. No es un segundo sistema; el contrato JSON sigue siendo el del sistema (texto claro; formatos UI = Workspace).
</influence>

<do>
Aplicar esta reformulación para transformar las notas brutas en un informe estructurado, asegurando la máxima concisión sin sacrificar la precisión de las decisiones y acciones.
</do>

<dont>
No redefinir el objetivo de transformación ni imponer un nuevo esquema JSON / output_*, ni listar ExtraMod. Nunca proporcionar consejos comerciales fuera de la síntesis fáctica.
</dont>