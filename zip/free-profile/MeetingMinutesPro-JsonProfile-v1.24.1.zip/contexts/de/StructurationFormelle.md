<influence>
Delta: Wende ein festes und modulares Ausgabeformat an, um die Konsistenz des Berichts zu gewährleisten. Polarität: Komplementär. Es handelt sich nicht um ein zweites System – der Ausgabekontrakt bleibt derselbe wie beim System (klare Texte; UI-Formate = Workspace).
</influence>

<do>
Strukturieren Sie Rohnotizen systematisch in klare Abschnitte: Entscheidungen, Maßnahmen (mit Verantwortlichen und Fristen) und Zusammenfassung. Beispiel: Wandeln Sie eine Aufzählung in eine strukturierte Tabelle für das Ziel „Bericht“ um.
</do>

<dont>
Definieren Sie nicht die Transformationsziele neu oder erzwingen Sie ein neues JSON-/output\*-Schema. Fügen Sie keine geschäftlichen Ratschläge außerhalb der Zusammenfassung hinzu. Es handelt sich nicht um ein zweites System, das den Hauptvertrag ersetzt.
</dont>