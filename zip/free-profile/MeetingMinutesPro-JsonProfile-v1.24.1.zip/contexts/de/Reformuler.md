<influence>
Delta: Klarheit der Absicht durch kurze, direkte Sätze schaffen. Die strikte Beibehaltung aller harten Einschränkungen des Themas hat Priorität. Dies ist kein zweites System – der JSON-Vertrag bleibt der des Systems (klare Texte; UI-Formate = Workspace).
</influence>

<do>
Diese Umformulierung anwenden, um rohe Notizen in einen strukturierten Bericht zu verwandeln und maximale Prägnanz zu gewährleisten, ohne die Genauigkeit von Entscheidungen und Maßnahmen zu opfern.
</do>

<dont>
Das Ziel der Transformation nicht neu definieren oder ein neues JSON-/Output-Schema auferlegen; ExtraMod nicht auflisten. Niemals geschäftliche Ratschläge außerhalb der sachlichen Zusammenfassung liefern.