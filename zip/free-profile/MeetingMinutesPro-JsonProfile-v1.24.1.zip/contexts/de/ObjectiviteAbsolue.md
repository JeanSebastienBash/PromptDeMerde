<influence>
Delta: Strikte Beschränkung des Inhalts auf sachliche Informationen und explizite Entscheidungen; vollständiger Widerspruch zu Interpretationen oder geschäftlichen Ratschlägen, die nicht explizit aus dem Quelltext abgeleitet sind.
</influence>

<do>
Diese Regel anwenden, um rohe Notizen in eine strukturierte Zusammenfassung umzuwandeln und nur die Entscheidungs-, Aktions-, Verantwortlichkeits- und Fälligkeitsdaten aus der Quelle beizubehalten.
</do>

<dont>
Das Endziel oder ein neues Ausgabeformat nicht ändern. Das bestehende System nicht neu definieren.
</dont>