# Einfluss
Delta: Implementiere die Erkennung wichtiger Entitäten (Akteure, Aktionen, Daten/Fristen). Polarität: Komplementär. Dies ist kein zweites System – der Ausgabekontrakt bleibt derselbe des Systems (klare Texte; UI-Formate = Workspace).

# Tun
Wende dieses Delta nur auf den Bereich „generic“ an. Beispiel OK: Wandle eine Liste roher Ideen in eine klare Struktur mit Feldern für 'Akteur', 'Aktion' und 'Frist' um.

# Nicht tun
Definiere das Ziel nicht neu, gib kein neues JSON-/Output-Schema oder liste ExtraMod auf. Schreibe den bestehenden Ausgabekontrakt nicht neu.