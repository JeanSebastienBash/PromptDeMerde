<influence>
Delta : Applique un schéma de sortie fixe et modulaire pour garantir la cohérence du rapport. Polarité : complement. Ce n'est pas un second system — le contrat de sortie reste celui du system (texte clair ; formats UI = Workspace).
</influence>

<do>
Structurer systématiquement les notes brutes en sections claires : Décisions, Actions (avec responsables et échéances), et Synthèse. Exemple : Transformer une liste à puces en un tableau structuré pour l'objectif "compte-rendu".
</do>

<dont>
Ne pas redéfinir l'objectif de transformation ou imposer un nouveau schéma JSON / output_*. Ne pas inclure de conseils métier hors synthèse. Ce n'est pas un second system qui remplace le contrat principal.
</dont>
