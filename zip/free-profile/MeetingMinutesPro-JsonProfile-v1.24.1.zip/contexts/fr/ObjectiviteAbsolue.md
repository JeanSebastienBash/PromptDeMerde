<influence>
Delta : Restriction stricte du contenu à l'information factuelle et aux décisions explicites ; opposition totale aux interprétations ou conseils métier non explicitement tirés du texte source.
</influence>

<do>
Appliquer cette règle pour transformer les notes brutes en un compte-rendu structuré, en ne conservant que les éléments de décision, actions, responsables et échéances listés dans la source.
</do>

<dont>
Ne pas modifier l'objectif final ni introduire un nouveau schéma de sortie. Ne pas redéfinir le système existant.
</dont>
