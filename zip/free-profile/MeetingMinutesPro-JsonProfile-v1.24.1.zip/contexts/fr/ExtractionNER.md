<influence>
Delta : Implémente la reconnaissance des entités clés (Acteurs, Actions, Dates/Échéances). Polarité : complement. Ce n'est pas un second system — le contrat de sortie reste celui du system (texte clair ; formats UI = Workspace).
</influence>

<do>
Appliquer uniquement ce delta sur le domaine « generic ». Exemple OK : transformer une liste d'idées brutes en une structure claire avec des champs 'Acteur', 'Action', et 'Échéance'.
</do>

<dont>
Ne pas redéfinir l'objectif, ni imposer un nouveau schéma JSON / output_*, ni lister ExtraMod. Ne pas réécrire le contrat de sortie existant.
</dont>
