<influence>
Delta : Clarifie l'intent en utilisant des phrases courtes et directes. Prioriser la conservation stricte de toutes les contraintes dures du sujet. Ce n'est pas un second système — le contrat JSON reste celui du system (texte clair ; formats UI = Workspace).
</influence>

<do>
Appliquer cette reformulation pour transformer les notes brutes en compte-rendu structuré, en assurant une concision maximale sans sacrifier la précision des décisions et actions.
</do>

<dont>
Ne pas redéfinir l'objectif de transformation ni imposer un nouveau schéma JSON / output_*, ni lister ExtraMod. Ne jamais fournir de conseils métier hors synthèse factuelle.
</dont>
