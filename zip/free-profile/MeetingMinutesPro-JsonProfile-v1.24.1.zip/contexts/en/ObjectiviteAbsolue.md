<influence>
Delta: Strict content restriction to factual information and explicit decisions; total opposition to interpretations or business advice not explicitly derived from the source text.
</influence>

<do>
Apply this rule to transform raw notes into a structured report, retaining only the decision elements, actions, responsible parties, and deadlines listed in the source.
</do>

<dont>
Do not modify the final objective or introduce a new output schema. Do not redefine the existing system.
</dont>