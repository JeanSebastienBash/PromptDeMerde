<influence>
Delta: Apply a fixed and modular output schema to ensure report consistency. Polarity: Complementary. This is not a secondary system—the output contract remains that of the primary system (clear text; UI formats = Workspace).
</influence>

<do>
Systematically structure raw notes into clear sections: Decisions, Actions (with owners and deadlines), and Summary. Example: Transform a bulleted list into a structured table for the "report" objective.
</do>

<dont>
Do not redefine the transformation objective or impose a new JSON/output_*. Do not include business advice outside of the summary. This is not a secondary system replacing the main contract.
</dont>