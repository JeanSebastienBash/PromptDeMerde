<influence>
Delta: Clarify intent by using short, direct sentences. Prioritize the strict preservation of all hard constraints of the subject. This is not a second system—the JSON contract remains that of the system (clear text; UI formats = Workspace).
</influence>

<do>
Apply this reformulation to transform raw notes into a structured report, ensuring maximum conciseness without sacrificing the accuracy of decisions and actions.
</do>

<dont>
Do not redefine the transformation objective or impose a new JSON/output_*, nor list ExtraMod. Never provide business advice outside of factual synthesis.
</dont>