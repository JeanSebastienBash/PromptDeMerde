<influence>
Delta: Implement the recognition of key entities (Actors, Actions, Dates/Deadlines). Polarity: complement. This is not a second system—the output contract remains that of the system (clear text; UI formats = Workspace).
</influence>

<do>
Apply only this delta to the "generic" domain. Example OK: transform a list of raw ideas into a clear structure with 'Actor', 'Action', and 'Deadline' fields.
</do>

<dont>
Do not redefine the objective, impose a new JSON/output_*, or list ExtraMod. Do not rewrite the existing output contract.
</dont>