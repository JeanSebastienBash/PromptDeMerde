补充说明（#活动标签）—仅影响增量；
不要替换系统JSON合约。合并时不要使用第二个模式。
<do>应用极性。</do>
<dont>复制输出_output_contract。</dont>