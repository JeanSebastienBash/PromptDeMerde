Retry: Generiere ein gültiges JSON {tag, prompt}, Struktur nur beeinflussend.
<anti_patterns>baby expert · ExtraMod</anti_patterns>