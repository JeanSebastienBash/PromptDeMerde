<role>User intention for creating a #Tag (generic domain).</role>
<scope>Request the desired delta of influence — not a second system.</scope>
<output_contract>Short intent text or JSON if requested.</output_contract>
<do>Clarify register / constraint aligned with: Raw meeting notes (transcript or bullet points) → structured summary: decisions, actions, owners, deadlines. Clear reformulation, no meta-advice</do>
<dont>Accept ExtraMod or baby « expert ».</dont>
<anti_patterns>Out of domain · junk · second system.</anti_patterns>