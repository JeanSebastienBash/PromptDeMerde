Retry: regenerate a valid JSON {tag,prompt} structure influencing only.
<anti_patterns>baby expert · ExtraMod</anti_patterns>